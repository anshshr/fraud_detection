import React, { useState, useEffect, useRef,useContext } from 'react';
import axios from 'axios';
import { motion, AnimatePresence } from 'framer-motion';
import { TransactionContext } from "../TransactionContext";

const Otp = ({setShowModal}) => {
  
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [resendDisabled, setResendDisabled] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const inputRefs = useRef([]);
  const {otpsuc, setotpsuc} = useContext(TransactionContext);

  // Setup refs for OTP inputs
  useEffect(() => {
    inputRefs.current = inputRefs.current.slice(0, 6);
  }, []);

  // Handle countdown timer for resend
  useEffect(() => {
    let timer;
    if (countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000);
    } else {
      setResendDisabled(false);
    }
    return () => clearTimeout(timer);
  }, [countdown]);

  const handleSendOTP = async () => {
    try {
      setLoading(true);
      setError('');
      
      const response = await axios.post('http://localhost:5000/api/users/sendotp', {
        email: 'rathoddhaval389@gmail.com' // This email is hardcoded as per the backend logic
      });
      
      setOtpSent(true);
      setSuccess('OTP sent successfully! Please check your email.');
      setCountdown(300); // 5 minutes countdown
      setResendDisabled(true);
    } catch (error) {
      setError(error.response?.data?.message || 'Failed to send OTP');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    try {
      setLoading(true);
      setError('');
      
      // Combine OTP digits
      const otpValue = otp.join('');
      
      if (otpValue.length !== 6) {
        setError('Please enter all 6 digits of the OTP');
        setLoading(false);
        return;
      }
      
      const response = await axios.post('http://localhost:5000/api/users/validateotp', {
        otp: otpValue
      });
      
      // Store token in localStorage
      localStorage.setItem('authToken', response.data.token);
      
      setSuccess('OTP verified successfully!');
      setotpsuc(true);
      setTimeout(() => {
        setShowModal(false);
        // Redirect or update UI state here after successful verification
      }, 2000);

      





    } catch (error) {
      setError(error.response?.data?.message || 'Failed to verify OTP');
      
    } finally {
      setLoading(false);
    }
  };

  // Handle OTP input changes
  const handleOtpChange = (e, index) => {
    const value = e.target.value;
    
    // Only allow digits
    if (value && !/^\d+$/.test(value)) return;
    
    // Update OTP array
    const newOtp = [...otp];
    newOtp[index] = value.slice(0, 1); // Only take the first character
    setOtp(newOtp);
    
    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1].focus();
    }
  };

  // Handle key press in OTP inputs
  const handleKeyDown = (e, index) => {
    // On backspace, clear current field and focus previous field
    if (e.key === 'Backspace') {
      if (!otp[index] && index > 0) {
        const newOtp = [...otp];
        newOtp[index - 1] = '';
        setOtp(newOtp);
        inputRefs.current[index - 1].focus();
      }
    }
  };

  // Handle paste
  const handlePaste = (e) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text/plain').trim();
    
    if (/^\d+$/.test(pastedData) && pastedData.length <= 6) {
      const newOtp = [...otp];
      for (let i = 0; i < pastedData.length; i++) {
        if (i < 6) newOtp[i] = pastedData[i];
      }
      setOtp(newOtp);
      
      // Focus last filled input or next empty input
      const lastIndex = Math.min(pastedData.length, 6) - 1;
      if (lastIndex < 5) {
        inputRefs.current[lastIndex + 1].focus();
      }
    }
  };

  const resetForm = () => {
    setOtp(['', '', '', '', '', '']);
    setOtpSent(false);
    setError('');
    setSuccess('');
  };

  return (
    <>
     

      <AnimatePresence>
       
          <motion.div 
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-75"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div 
              className="relative bg-gray-800 rounded-xl shadow-2xl w-full max-w-md p-6 overflow-hidden"
              initial={{ scale: 0.9, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 20, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 500 }}
            >
              {/* Background gradient animation */}
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-purple-500 via-blue-500 to-teal-400 background-animate"></div>
              
              <button 
                onClick={() => {
                  setShowModal(false);
                  resetForm();
                }}
                className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>

              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-white mb-1">OTP Verification</h3>
                <p className="text-gray-400">
                  {!otpSent 
                    ? "Secure your account with one-time password" 
                    : "Enter the 6-digit code sent to your email"}
                </p>
              </div>

              {error && (
                <motion.div 
                  className="mb-4 p-3 bg-red-900 bg-opacity-40 text-red-200 rounded-lg text-sm"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  {error}
                </motion.div>
              )}

              {success && (
                <motion.div 
                  className="mb-4 p-3 bg-green-900 bg-opacity-40 text-green-200 rounded-lg text-sm"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  {success}
                </motion.div>
              )}

              <div className="space-y-6">
                {!otpSent ? (
                  <motion.button
                    onClick={handleSendOTP}
                    disabled={loading}
                    className={`w-full py-3 rounded-lg font-semibold transition-all duration-300 
                      ${loading ? 'bg-gray-600 text-gray-400' : 'bg-purple-600 text-white hover:bg-purple-700'}`}
                    whileHover={!loading ? { scale: 1.02 } : {}}
                    whileTap={!loading ? { scale: 0.98 } : {}}
                  >
                    {loading ? (
                      <div className="flex items-center justify-center">
                        <svg className="animate-spin h-5 w-5 mr-2 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Sending OTP...
                      </div>
                    ) : "Send OTP"}
                  </motion.button>
                ) : (
                  <div className="space-y-6">
                    <div className="flex justify-center space-x-2">
                      {otp.map((digit, index) => (
                        <motion.input
                          key={index}
                          type="text"
                          maxLength={1}
                          ref={el => inputRefs.current[index] = el}
                          value={digit}
                          onChange={(e) => handleOtpChange(e, index)}
                          onKeyDown={(e) => handleKeyDown(e, index)}
                          onPaste={index === 0 ? handlePaste : null}
                          className="w-12 h-14 text-center text-xl font-bold text-white bg-gray-700 border border-gray-600 rounded-lg focus:border-purple-500 focus:ring-2 focus:ring-purple-500 focus:outline-none"
                          initial={{ scale: 0, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          transition={{ delay: index * 0.05 }}
                        />
                      ))}
                    </div>

                    {countdown > 0 && (
                      <p className="text-center text-gray-400 text-sm">
                        Resend code in <span className="text-purple-400">{Math.floor(countdown / 60)}:{(countdown % 60).toString().padStart(2, '0')}</span>
                      </p>
                    )}

                    <div className="flex flex-col sm:flex-row gap-3">
                      <motion.button
                        onClick={handleVerifyOTP}
                        disabled={loading}
                        className={`flex-1 py-3 rounded-lg font-semibold transition-all duration-300
                          ${loading ? 'bg-gray-600 text-gray-400' : 'bg-purple-600 text-white hover:bg-purple-700'}`}
                        whileHover={!loading ? { scale: 1.02 } : {}}
                        whileTap={!loading ? { scale: 0.98 } : {}}
                      >
                        {loading ? (
                          <div className="flex items-center justify-center">
                            <svg className="animate-spin h-5 w-5 mr-2 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Verifying...
                          </div>
                        ) : "Verify OTP"}
                      </motion.button>

                      <motion.button
                        onClick={handleSendOTP}
                        disabled={loading || resendDisabled}
                        className={`flex-1 py-3 border rounded-lg font-semibold transition-all duration-300
                          ${loading || resendDisabled ? 'border-gray-600 text-gray-500' : 'border-purple-500 text-purple-400 hover:bg-purple-900 hover:bg-opacity-20'}`}
                        whileHover={!loading && !resendDisabled ? { scale: 1.02 } : {}}
                        whileTap={!loading && !resendDisabled ? { scale: 0.98 } : {}}
                      >
                        Resend OTP
                      </motion.button>
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-8 text-center text-sm text-gray-500">
                <p>Protected by advanced encryption</p>
              </div>
            </motion.div>
          </motion.div>
      
      </AnimatePresence> </>

    
 
  );
};

export default Otp;