import React, { useState } from 'react';
import { ChevronDown, Menu, X, Shield, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);

  const toggleDropdown = (index) => {
    if (activeDropdown === index) {
      setActiveDropdown(null);
    } else {
      setActiveDropdown(index);
    }
  };

  const navItems = [
    {
      name: 'Features',
      hasDropdown: true,
      dropdownItems: [
        { name: 'Real-time Monitoring', link: '#monitoring' },
        { name: 'Anomaly Detection', link: '#detection' },
        { name: 'Actionable Alerts', link: '#alerts' },
        { name: 'Regulatory Compliance', link: '#compliance' }
      ]
    },
    {
      name: 'Users',
      hasDropdown: true,
      dropdownItems: [
        { name: 'Amit', link: '/userdashboard/67e88643fbf909a686e608ac' },
        { name: 'Priya', link: '/userdashboard/67e886bafbf909a686e608af' },
        { name: 'Data Analysis', link: '#data-analysis' },
        { name: 'Secure Architecture', link: '#architecture' }
      ]
    },
    {
      name: 'Evaluation',
      hasDropdown: true,
      dropdownItems: [
        { name: 'Risk Analysis', link: '#risk-analysis' },
        { name: 'AI Capabilities', link: '#ai-capabilities' },
        { name: 'Architecture', link: '#arch-eval' },
        { name: 'Presentation Skills', link: '#presentation' }
      ]
    },
    { name: 'About', hasDropdown: false, link: '#about' },
   
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-gray-900/60 border-b border-gray-800/50 shadow-lg shadow-green-900/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <Link to="/" className="flex items-center gap-2">
              <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-2 rounded-lg">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <span className="text-white font-bold text-xl">FraudShield</span>
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-4">
              {navItems.map((item, index) => (
                <div key={index} className="relative group">
                  <button
                    onClick={() => item.hasDropdown && toggleDropdown(index)}
                    className="text-gray-300 hover:text-green-400 px-3 py-2 rounded-md text-sm font-medium flex items-center transition-colors"
                  >
                    {item.name}
                    {item.hasDropdown && (
                      <ChevronDown
                        className={`ml-1 h-4 w-4 transition-transform ${
                          activeDropdown === index ? 'rotate-180' : ''
                        }`}
                      />
                    )}
                  </button>
                  
                  {/* Dropdown Menu */}
                  {item.hasDropdown && activeDropdown === index && (
                    <div className="absolute left-0 mt-2 w-48 backdrop-blur-md bg-gray-800/80 border border-gray-700/50 rounded-lg shadow-lg shadow-green-900/10 z-50 transition-all">
                      <div className="py-1">
                        {item.dropdownItems.map((dropdownItem, dropdownIndex) => (
                          <a
                            key={dropdownIndex}
                            href={dropdownItem.link}
                            className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700/50 hover:text-green-400 transition-colors"
                          >
                            {dropdownItem.name}
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {/* Register Button */}
          <div className="hidden w-[30%] h-full justify-center md:flex items-center space-x-4"> 

          <Link to="register"className="bg-gradient-to-r mb-4 from-green-500 to-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-1 hover:opacity-90 transition-all shadow-md shadow-green-500/20 w-full justify-center mt-4">
              Register As User <ArrowRight size={16} />
            </Link>

          <Link to="bankdepartment"className="bg-gradient-to-r mb-5 from-green-500 to-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-1 hover:opacity-90 transition-all shadow-md shadow-green-500/20 w-full justify-center mt-4">
              Register <ArrowRight size={16} />
            </Link>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700/50 focus:outline-none"
            >
              {isOpen ? (
                <X className="block h-6 w-6" aria-hidden="true" />
              ) : (
                <Menu className="block h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden backdrop-blur-md bg-gray-900/95 border-b border-gray-800/50">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navItems.map((item, index) => (
              <div key={index}>
                <button
                  onClick={() => item.hasDropdown && toggleDropdown(index)}
                  className="text-gray-300 hover:bg-gray-700/50 hover:text-green-400 block px-3 py-2 rounded-md text-base font-medium w-full text-left flex items-center justify-between"
                >
                  {item.name}
                  {item.hasDropdown && (
                    <ChevronDown
                      className={`ml-1 h-4 w-4 transition-transform ${
                        activeDropdown === index ? 'rotate-180' : ''
                      }`}
                    />
                  )}
                </button>
                
                {/* Mobile Dropdown */}
                {item.hasDropdown && activeDropdown === index && (
                  <div className="pl-4 py-2 space-y-1 border-l-2 border-green-500/50 ml-3">
                    {item.dropdownItems.map((dropdownItem, dropdownIndex) => (
                      <a
                        key={dropdownIndex}
                        href={dropdownItem.link}
                        className="block px-3 py-2 rounded-md text-sm text-gray-400 hover:text-green-400 transition-colors"
                      >
                        {dropdownItem.name}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <Link to="register"className="bg-gradient-to-r from-green-500 to-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-1 hover:opacity-90 transition-all shadow-md shadow-green-500/20 w-full justify-center mt-4">
              Register As User <ArrowRight size={16} />
            </Link>
            <Link to="bankdepartment"className="bg-gradient-to-r from-green-500 to-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-1 hover:opacity-90 transition-all shadow-md shadow-green-500/20 w-full justify-center mt-4">
              Register <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Header;