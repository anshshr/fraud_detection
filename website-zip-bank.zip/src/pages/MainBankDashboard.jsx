import React,{useState,useEffect} from 'react'
import { 
  Home, 
  Map, 
  LogOut, 
  AlertTriangle, 
  Eye, 
  Search,
  ArrowUpRight,
  CreditCard,
  Wallet,
  BarChart4,
  Activity,
  Users
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { db } from "../firebase/firebase";
import { collection, getDocs } from "firebase/firestore";
import { useNavigate } from 'react-router-dom';

const MainBankDashboard = () => {
  const navigate = useNavigate();
// Component for stat card


 const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const usersCollection = collection(db, "userDetails"); // Adjust collection name
        const userSnapshot = await getDocs(usersCollection);
        const userList = userSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
       
        setUsers(userList);
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };

    fetchUsers();
  }, []);



  const [totalTransferAmount, setTotalTransferAmount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [usercount,setUserCount]=useState(null);

  useEffect(() => {
    const fetchTransactionReportsAndCalculateSum = async () => {
      // const tuser = collection(db, 'serDetails');
      // const tuser2 = await getDocs(tuser);
      // setUserCount(tuser2.length())


      setLoading(true);
      setError(null);
      let sum = 0;
      try {
        const transactionsReportCollection = collection(db, 'transactions_report');
        const querySnapshot = await getDocs(transactionsReportCollection);



       
        querySnapshot.forEach((doc) => {
          const reportData = doc.data();
          // Check if the nested structure exists and has transfer_amount
          if (
            reportData &&
            reportData.transaction_analysis &&
            reportData.transaction_analysis.risk_evaluation &&
            Array.isArray(reportData.transaction_analysis.risk_evaluation.risk_factors) &&
            reportData.transaction_analysis.risk_evaluation.risk_factors.length > 0 &&
            reportData.transaction_analysis.risk_evaluation.risk_factors[0].relevant_data &&
            reportData.transaction_analysis.risk_evaluation.risk_factors[0].relevant_data.transfer_amount
          ) {
            // Assuming transfer_amount is a string, convert it to a number
            const transferAmount = parseFloat(
              reportData.transaction_analysis.risk_evaluation.risk_factors[0].relevant_data.transfer_amount
            );
            if (!isNaN(transferAmount)) {
              sum += transferAmount;
            } else {
              console.warn(`Invalid transfer_amount found in document ${doc.id}:`, reportData.transaction_analysis.risk_evaluation.risk_factors[0].relevant_data.transfer_amount);
            }
          }
        });
        console.log(sum);
        setTotalTransferAmount(sum);
      } catch (e) {
        setError("Error fetching transaction reports: " + e.message);
      } finally {
        setLoading(false);
      }
    };



    fetchTransactionReportsAndCalculateSum();
  }, []);

  if (loading) {
    return <p>Loading transaction reports and calculating sum...</p>;
  }

  if (error) {
    return <p>Error: {error}</p>;
  }
  





const StatCard = ({ title, value, icon, change }) => (
  <div className="bg-slate-800/50 backdrop-blur-md rounded-xl p-4 flex flex-col">
    <div className="flex justify-between items-start mb-4">
      <div>
        <h3 className="text-white/70 text-sm">{title}</h3>
        <p className="text-white text-2xl font-semibold mt-1">{value}</p>
      </div>
      <div className="p-2 rounded-lg bg-slate-700/50">
        {icon}
      </div>
    </div>
    <div className="text-xs text-teal-400 flex items-center mt-2">
      <ArrowUpRight size={14} className="mr-1" /> {change} from last month
    </div>
  </div>
);

// Component for fraud risk indicator
const FraudRiskIndicator = ({ level }) => {
  const getColor = () => {
    switch(level) {
      case 5: return "bg-red-500";
      case 4: return "bg-orange-500";
      case 3: return "bg-yellow-500";
      case 2: return "bg-blue-500";
      default: return "bg-green-500";
    }
  };
  
  const getText = () => {
    switch(level) {
      case 5: return "Critical";
      case 4: return "High";
      case 3: return "Medium";
      case 2: return "Low";
      default: return "Safe";
    }
  };
  
  return (
    <div className="flex items-center">
      <div className={`h-2.5 w-2.5 rounded-full ${getColor()} mr-2`}></div>
      <span className={`text-sm ${level >= 4 ? 'text-red-400' : 'text-white/80'}`}>{getText()}</span>
    </div>
  );
};











 

// Stats data
const statsData = [
  { title: 'Total Transactions', value: totalTransferAmount+" ₹", icon: <Activity size={24} className="text-teal-400" />, change: '+12%' },
  { title: 'Flagged Transactions', value: '3', icon: <AlertTriangle size={24} className="text-red-400" />, change: '+5%' },
  { title: 'Active Users', value: usercount||6, icon: <Users size={24} className="text-blue-400" />, change: '+8%' },
  { title: 'Fraud Prevented', value: '1', icon: <Wallet size={24} className="text-purple-400" />, change: '+15%' },
];






  return (
   
    <div className="space-y-6 pt-[5rem]">
      <div className="flex justify-between items-center">
        <h1 className="text-white text-2xl font-bold">Fraud Detection Dashboard</h1>
        <div className="relative">
          <input 
            type="text" 
            placeholder="Search transactions..." 
            className="bg-slate-800/50 backdrop-blur-sm rounded-lg pl-10 pr-4 py-2 text-white/80 w-64 focus:outline-none focus:ring-1 focus:ring-teal-500 placeholder-white/50"
          />
          <Search className="absolute left-3 top-2.5 text-white/50" size={18} />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statsData.map((stat, index) => (
          <StatCard key={index} {...stat} />
        ))}
      </div>

      <div className="bg-slate-800/60 backdrop-blur-md rounded-xl p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-white text-lg font-semibold">Recent Transactions</h2>
          <div className="flex space-x-2">
            <button className="bg-slate-700/50 hover:bg-slate-700 text-white/80 px-3 py-1.5 rounded-lg text-sm">
              All Transactions
            </button>
            <button className="bg-red-500/20 hover:bg-red-500/30 text-red-400 px-3 py-1.5 rounded-lg text-sm flex items-center">
              <AlertTriangle size={14} className="mr-1.5" /> Flagged Only
            </button>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-white/50 text-xs border-b border-slate-700">
                <th className="pb-3 text-left">User ID</th>
                <th className="pb-3 text-left">Account No.</th>
              
                <th className="pb-3 text-left">Location</th>
                <th className="pb-3 text-left">Bank Name</th>
                <th className="pb-3 text-left">Branch</th>
                <th className="pb-3 text-left">State</th>
              
                <th className="pb-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id} className="border-b border-slate-700/50 text-sm">
                  <td className="py-4 text-white/90">{user.id}</td>
                  <td className="py-4 text-white/90">{user["Account Number"] || "-"} </td>
                 
                  <td className="py-4 text-white/90">{user.Address.substring(0, 19) || "-"}</td>
                  <td className="py-4 text-white/90">{user["Bank Name"] || "-"}</td>
                  
                  <td className="py-4 text-white/70">{user.Branch || "-"}</td>
                  <td className="py-4">
                    {/* <FraudRiskIndicator level={user.State} /> */}
                    {user.State || "-"} 
                  </td>
                  <td className="py-4 text-right">
                    <button onClick={()=> navigate(`/userbank/${user.id}`)} className="bg-slate-700/70 hover:bg-slate-700 text-white/80 p-1.5 rounded-lg">
                      <Eye size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
 
  )
}

export default MainBankDashboard