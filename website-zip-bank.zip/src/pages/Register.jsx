import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { motion } from 'framer-motion';

const Register = () => {
  // Form state
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: 'customer',
    personalDetails: {
      dateOfBirth: '',
      phoneNumber: '',
      address: {
        street: '',
        city: '',
        state: '',
        zipCode: '',
        country: '',
      },
    },
    bankDetails: {
      accountNumber: '',
      ifscCode: '',
      balance: 0,
    },
  });

  // Card animation state
  const [isFlipped, setIsFlipped] = useState(false);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const cardRef = useRef(null);

  // Form section state (for multi-step form)
  const [formSection, setFormSection] = useState('personal');

  // Error and loading states
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  // Handle form input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    
    if (name.includes('.')) {
      const parts = name.split('.');
      if (parts.length === 2) {
        setFormData({
          ...formData,
          [parts[0]]: {
            ...formData[parts[0]],
            [parts[1]]: value,
          },
        });
      } else if (parts.length === 3) {
        setFormData({
          ...formData,
          [parts[0]]: {
            ...formData[parts[0]],
            [parts[1]]: {
              ...formData[parts[0]][parts[1]],
              [parts[2]]: value,
            },
          },
        });
      }
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }

    // Flip card when entering bank details
    if (name.includes('bankDetails')) {
      if (!isFlipped) setIsFlipped(true);
    } else {
      if (isFlipped) setIsFlipped(false);
    }
  };

  // 3D card effect
  useEffect(() => {
    if (!cardRef.current) return;

    const handleMouseMove = (e) => {
      if (formSection !== 'bank') return;
      
      const card = cardRef.current;
      const rect = card.getBoundingClientRect();
      
      // Calculate mouse position relative to card center
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const mouseX = e.clientX;
      const mouseY = e.clientY;
      
      // Calculate rotation values (limited to +/- 15 degrees)
      const rotateY = ((mouseX - centerX) / (rect.width / 2)) * 10;
      const rotateX = -((mouseY - centerY) / (rect.height / 2)) * 10;
      
      setRotateX(rotateX);
      setRotateY(rotateY);
    };

    document.addEventListener('mousemove', handleMouseMove);
    return () => document.removeEventListener('mousemove', handleMouseMove);
  }, [formSection]);

  // Form submission handler
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    try {
      const response = await axios.post('http://localhost:5000/api/users/users', formData);
      setSuccess(true);
      console.log('User registered:', response.data);
    } catch (error) {
      if (error.response && error.response.data) {
        setErrors(error.response.data);
      } else {
        setErrors({ general: 'An unexpected error occurred. Please try again.' });
      }
      console.error('Registration error:', error);
    } finally {
      setLoading(false);
    }
  };

  // Next step handler
  const handleNextStep = () => {
    if (formSection === 'personal') {
      setFormSection('address');
    } else if (formSection === 'address') {
      setFormSection('bank');
    }
  };

  // Previous step handler
  const handlePrevStep = () => {
    if (formSection === 'address') {
      setFormSection('personal');
    } else if (formSection === 'bank') {
      setFormSection('address');
    }
  };

  // Card component
  const Card = () => (
    <motion.div
      ref={cardRef}
      className="relative w-full max-w-md h-56 rounded-xl mb-8 perspective-1000"
      style={{
        // transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`,
        transition: 'transform 0.8s ease',
      }}
    >
      <motion.div
        className="w-full h-full relative preserve-3d"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Front of card */}
        <div className="absolute w-full h-full backface-hidden rounded-xl p-6 text-white bg-gradient-to-br from-blue-600 to-purple-800 shadow-xl flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <div className="flex flex-col">
              <span className="text-xs opacity-80">Card Holder</span>
              <span className="font-bold text-lg truncate max-w-40">
                {formData.name || 'Your Name'}
              </span>
            </div>
            <div className="h-10 w-12">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M44 24C44 35.0457 35.0457 44 24 44C12.9543 44 4 35.0457 4 24C4 12.9543 12.9543 4 24 4C35.0457 4 44 12.9543 44 24Z" fill="#F9A825"/>
                <path d="M24 36C30.6274 36 36 30.6274 36 24C36 17.3726 30.6274 12 24 12C17.3726 12 12 17.3726 12 24C12 30.6274 17.3726 36 24 36Z" fill="#E53935"/>
              </svg>
            </div>
          </div>
          
          <div className="mt-4">
            <div className="h-8 w-12 bg-gray-200 bg-opacity-20 rounded"></div>
          </div>
          
          <div className="mt-4">
            <span className="text-xs opacity-80">Card Number</span>
            <div className="font-mono text-lg tracking-wider">
              {formData.bankDetails.accountNumber 
                ? `${formData.bankDetails.accountNumber.slice(0, 4)} **** **** ${formData.bankDetails.accountNumber.slice(-4)}` 
                : '**** **** **** ****'}
            </div>
          </div>
          
          <div className="flex justify-between mt-4">
            <div>
              <span className="text-xs opacity-80">Valid Till</span>
              <div>**/**</div>
            </div>
            <div>
              <span className="text-xs opacity-80">CVV</span>
              <div>***</div>
            </div>
          </div>
        </div>
        
        {/* Back of card */}
        <div className="absolute w-full h-full backface-hidden rounded-xl p-6 text-white bg-gradient-to-br from-purple-800 to-indigo-900 shadow-xl rotate-y-180 flex flex-col justify-between">
          <div className="h-10 w-full bg-black my-4"></div>
          
          <div className="flex flex-col items-end">
            <span className="text-xs opacity-80">IFSC Code</span>
            <div className="font-mono text-lg tracking-wider">
              {formData.bankDetails.ifscCode || 'XXXX0000XXX'}
            </div>
          </div>
          
          <div className="mt-4">
            <span className="text-xs opacity-80">Account Type</span>
            <div className="font-bold">Savings Account</div>
          </div>
          
          <div className="mt-4 text-xs opacity-70 text-right">
            This card is property of the bank and must be returned upon request
          </div>
        </div>
      </motion.div>
    </motion.div>
  );

  // Success message component
  const SuccessMessage = () => (
    <div className="text-center py-16 px-4">
      <div className="w-16 h-16 bg-green-500 rounded-full mx-auto flex items-center justify-center mb-6">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
        </svg>
      </div>
      <h2 className="text-2xl font-bold text-white mb-2">Registration Successful!</h2>
      <p className="text-gray-300 mb-6">Your account has been created successfully.</p>
      <button
        className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        onClick={() => window.location.href = '/login'}
      >
        Go to Login
      </button>
    </div>
  );

  // Render personal details section
  const renderPersonalDetails = () => (
    <>
      <h2 className="text-xl font-bold text-white mb-6">Personal Information</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-gray-300 mb-1">Full Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        
        <div>
          <label className="block text-gray-300 mb-1">Email Address</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        
        <div>
          <label className="block text-gray-300 mb-1">Password</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        
        <div>
          <label className="block text-gray-300 mb-1">Date of Birth</label>
          <input
            type="date"
            name="personalDetails.dateOfBirth"
            value={formData.personalDetails.dateOfBirth}
            onChange={handleChange}
            className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        
        <div>
          <label className="block text-gray-300 mb-1">Phone Number</label>
          <input
            type="tel"
            name="personalDetails.phoneNumber"
            value={formData.personalDetails.phoneNumber}
            onChange={handleChange}
            className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        
        <div>
          <label className="block text-gray-300 mb-1">Role</label>
          <select
            name="role"
            value={formData.role}
            onChange={handleChange}
            className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="customer">Customer</option>
            <option value="admin">Admin</option>
          </select>
        </div>
      </div>
    </>
  );

  // Render address section
  const renderAddressDetails = () => (
    <>
      <h2 className="text-xl font-bold text-white mb-6">Address Information</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-gray-300 mb-1">Street Address</label>
          <input
            type="text"
            name="personalDetails.address.street"
            value={formData.personalDetails.address.street}
            onChange={handleChange}
            className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-300 mb-1">City</label>
            <input
              type="text"
              name="personalDetails.address.city"
              value={formData.personalDetails.address.city}
              onChange={handleChange}
              className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          
          <div>
            <label className="block text-gray-300 mb-1">State</label>
            <input
              type="text"
              name="personalDetails.address.state"
              value={formData.personalDetails.address.state}
              onChange={handleChange}
              className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-300 mb-1">Zip Code</label>
            <input
              type="text"
              name="personalDetails.address.zipCode"
              value={formData.personalDetails.address.zipCode}
              onChange={handleChange}
              className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          
          <div>
            <label className="block text-gray-300 mb-1">Country</label>
            <input
              type="text"
              name="personalDetails.address.country"
              value={formData.personalDetails.address.country}
              onChange={handleChange}
              className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
        </div>
      </div>
    </>
  );

  // Render bank details section
  const renderBankDetails = () => (
    <>
      <h2 className="text-xl font-bold text-white mb-6">Banking Information</h2>
      
      <Card />
      
      <div className="space-y-4">
        <div>
          <label className="block text-gray-300 mb-1">Account Number</label>
          <input
            type="text"
            name="bankDetails.accountNumber"
            value={formData.bankDetails.accountNumber}
            onChange={handleChange}
            className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        
        <div>
          <label className="block text-gray-300 mb-1">IFSC Code</label>
          <input
            type="text"
            name="bankDetails.ifscCode"
            value={formData.bankDetails.ifscCode}
            onChange={handleChange}
            className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        
        <div>
          <label className="block text-gray-300 mb-1">Initial Balance</label>
          <input
            type="number"
            name="bankDetails.balance"
            value={formData.bankDetails.balance}
            onChange={handleChange}
            className="w-full bg-gray-800 bg-opacity-50 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>
    </>
  );

  // Render current form section
  const renderFormSection = () => {
    switch (formSection) {
      case 'personal':
        return renderPersonalDetails();
      case 'address':
        return renderAddressDetails();
      case 'bank':
        return renderBankDetails();
      default:
        return renderPersonalDetails();
    }
  };

  // Render navigation buttons
  const renderNavigationButtons = () => (
    <div className="flex justify-between mt-8">
      {formSection !== 'personal' && (
        <button
          type="button"
          onClick={handlePrevStep}
          className="px-6 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors"
        >
          Back
        </button>
      )}
      
      {formSection === 'personal' && (
        <button
          type="button"
          onClick={handleNextStep}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors ml-auto"
        >
          Next
        </button>
      )}
      
      {formSection === 'address' && (
        <button
          type="button"
          onClick={handleNextStep}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Next
        </button>
      )}
      
      {formSection === 'bank' && (
        <button
          type="submit"
          disabled={loading}
          className={`px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
        >
          {loading ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Processing...
            </>
          ) : (
            'Register'
          )}
        </button>
      )}
    </div>
  );

  // Main component return
  return (
    <div className="min-h-screen bg-gray-900 py-12 px-4 sm:px-6 lg:px-8 flex items-center justify-center bg-gradient-to-b from-gray-900 via-gray-800 to-black">
      <div className="max-w-md w-full space-y-8">
        {success ? (
          <SuccessMessage />
        ) : (
          <>
            <div className="text-center">
              <h1 className="text-3xl font-extrabold text-white">Create Your Account</h1>
              <p className="mt-2 text-sm text-gray-400">Fill out the form to register a new account</p>
              
              {/* Progress indicators */}
              <div className="flex items-center justify-center mt-6 space-x-2">
                <div className={`h-2 w-16 rounded-full ${formSection === 'personal' ? 'bg-blue-500' : 'bg-gray-600'}`}></div>
                <div className={`h-2 w-16 rounded-full ${formSection === 'address' ? 'bg-blue-500' : 'bg-gray-600'}`}></div>
                <div className={`h-2 w-16 rounded-full ${formSection === 'bank' ? 'bg-blue-500' : 'bg-gray-600'}`}></div>
              </div>
            </div>
            
            {/* Error display */}
            {errors.general && (
              <div className="bg-red-500 bg-opacity-20 border border-red-400 text-red-200 px-4 py-3 rounded-lg mb-4">
                {errors.general}
              </div>
            )}
            
            {/* Main form */}
            <div className="mt-8 bg-gray-800 bg-opacity-50 backdrop-blur-md rounded-xl shadow-xl p-6 border border-gray-700">
              <form onSubmit={handleSubmit}>
                {renderFormSection()}
                {renderNavigationButtons()}
              </form>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Register;

// Add these styles to your CSS or tailwind.config.js
