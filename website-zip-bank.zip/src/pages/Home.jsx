import React, { useEffect } from 'react';
import { ArrowRight, Shield, Activity, Zap, Database, PieChart, FileText, Users } from 'lucide-react';
import logo1 from "../images/logo1.png"
const Home = () => {
  useEffect(() => {
    // Animation for elements when they come into view
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fadeIn');
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.animate-on-scroll').forEach(element => {
      observer.observe(element);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br pt-[5rem] from-gray-900 via-gray-800 to-black text-white">
      {/* Hero Section */}
      <section className="pt-20 pb-16 px-4 md:px-8 lg:px-16">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center gap-10">
            <div className="md:w-1/2 animate-on-scroll opacity-0">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-emerald-600">
                AI Based Financial Fraud Detection System
              </h1>
              <p className="text-gray-300 text-xl mb-8">
                Exceed the expected with next-generation AI-powered fraud prevention for modern financial institutions.
              </p>
              <button className="bg-gradient-to-r from-green-500 to-emerald-700 text-white px-8 py-3 rounded-lg font-medium flex items-center gap-2 hover:opacity-90 transition-all shadow-lg shadow-green-500/20">
                Learn More <ArrowRight size={18} />
              </button>

              <div className="flex items-center gap-8 mt-12">
                <div className="text-center">
                  <p className="text-3xl font-bold text-green-400">11+</p>
                  <p className="text-gray-400">Years</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-green-400">150+</p>
                  <p className="text-gray-400">Clients</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-green-400">400+</p>
                  <p className="text-gray-400">Products</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-green-400">140+</p>
                  <p className="text-gray-400">Global Team</p>
                </div>
              </div>
            </div>

            <div className="md:w-1/2 animate-on-scroll opacity-0">
              <div className="backdrop-blur-md bg-gray-800/40 border border-gray-700/50 rounded-2xl p-6 shadow-xl shadow-green-500/5">
                <div className="relative">
                  <div className="absolute -top-10 -right-10 w-40 h-40 bg-green-500/20 rounded-full blur-3xl"></div>
                  <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-emerald-500/20 rounded-full blur-3xl"></div>
                  
                  <img 
                    src={logo1} 
                    alt="AI Fraud Detection Dashboard" 
                    className="w-full h-auto rounded-lg shadow-lg"
                  />
                  
                  <div className="absolute -bottom-6 -right-6 bg-gradient-to-r from-green-500 to-emerald-600 p-4 rounded-lg shadow-lg">
                    <PieChart className="w-10 h-10" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 md:px-8 lg:px-16 bg-gray-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 animate-on-scroll opacity-0">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-green-400">
              Key Features
            </h2>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto">
              Our AI-powered system uses multiple intelligent agents to monitor and analyze financial transactions in real-time.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-xl p-6 shadow-lg transform hover:translate-y-[-5px] transition-all duration-300 animate-on-scroll opacity-0">
              <div className="bg-gradient-to-r from-green-500 to-emerald-600 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Activity className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-white">Real-time Monitoring</h3>
              <p className="text-gray-300">
                Monitor and analyze financial transactions as they occur to instantly detect suspicious patterns.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-xl p-6 shadow-lg transform hover:translate-y-[-5px] transition-all duration-300 animate-on-scroll opacity-0">
              <div className="bg-gradient-to-r from-green-500 to-emerald-600 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Shield className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-white">Anomaly Detection</h3>
              <p className="text-gray-300">
                Advanced AI algorithms identify unusual patterns that may indicate fraudulent activity.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-xl p-6 shadow-lg transform hover:translate-y-[-5px] transition-all duration-300 animate-on-scroll opacity-0">
              <div className="bg-gradient-to-r from-green-500 to-emerald-600 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Zap className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-white">Actionable Alerts</h3>
              <p className="text-gray-300">
                Receive contextual insights and clear alerts when suspicious activity is detected.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-xl p-6 shadow-lg transform hover:translate-y-[-5px] transition-all duration-300 animate-on-scroll opacity-0">
              <div className="bg-gradient-to-r from-green-500 to-emerald-600 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Database className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-white">Regulatory Compliance</h3>
              <p className="text-gray-300">
                Stay compliant with financial regulations while effectively combating fraud.
              </p>
            </div>

            {/* Feature 5 */}
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-xl p-6 shadow-lg transform hover:translate-y-[-5px] transition-all duration-300 animate-on-scroll opacity-0">
              <div className="bg-gradient-to-r from-green-500 to-emerald-600 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <FileText className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-white">Comprehensive Reporting</h3>
              <p className="text-gray-300">
                Access detailed reports and analytics to understand fraud patterns and improve prevention.
              </p>
            </div>

            {/* Feature 6 */}
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-xl p-6 shadow-lg transform hover:translate-y-[-5px] transition-all duration-300 animate-on-scroll opacity-0">
              <div className="bg-gradient-to-r from-green-500 to-emerald-600 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-white">Multi-Agent System</h3>
              <p className="text-gray-300">
                Leverage multiple specialized AI agents working together to improve detection accuracy.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Evaluation Criteria Section */}
      <section className="py-20 px-4 md:px-8 lg:px-16">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 animate-on-scroll opacity-0">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-green-400">
              Evaluation Criteria
            </h2>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto">
              Submissions will be evaluated based on the following criteria
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-6 animate-on-scroll opacity-0">
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-lg p-5 text-center">
              <p className="text-white font-semibold">Risk Analysis Coverage</p>
            </div>
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-lg p-5 text-center">
              <p className="text-white font-semibold">AI Capabilities</p>
            </div>
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-lg p-5 text-center">
              <p className="text-white font-semibold">Architecture</p>
            </div>
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-lg p-5 text-center">
              <p className="text-white font-semibold">Presentation Skills</p>
            </div>
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-lg p-5 text-center">
              <p className="text-white font-semibold">Teamwork & Creativity</p>
            </div>
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-lg p-5 text-center">
              <p className="text-white font-semibold">Frontend & Backend</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 md:px-8 lg:px-16 bg-gray-900/50">
        <div className="max-w-4xl mx-auto animate-on-scroll opacity-0">
          <div className="backdrop-blur-lg bg-gradient-to-r from-gray-800/40 to-gray-900/40 border border-gray-700/50 rounded-2xl p-10 shadow-xl relative overflow-hidden">
            <div className="absolute -top-24 -right-24 w-64 h-64 bg-green-500/10 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl"></div>
            
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-center bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-emerald-600">
                Ready to Participate?
              </h2>
              <p className="text-gray-300 text-lg mb-8 text-center">
                Join HackNUthon 6.0 and develop an innovative AI-based Financial Fraud Detection System
              </p>
              <div className="flex justify-center">
                <button className="bg-gradient-to-r from-green-500 to-emerald-700 text-white px-8 py-3 rounded-lg font-medium flex items-center gap-2 hover:opacity-90 transition-all shadow-lg shadow-green-500/20">
                  Register Now <ArrowRight size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Add CSS for animations */}
      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .animate-fadeIn {
          animation: fadeIn 0.8s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default Home;