import React from 'react'
import { 
  Home, 
  Map, 
  LogOut, 
  AlertTriangle, 
  Eye, 
  Search,
  ArrowUpRight,
  CreditCard,
  Wallet,
  BarChart4,
  Activity,
  Users
} from 'lucide-react';
import Map12 from '../components/Map12';

export const FraudDetectionMap = () => {
  return (
    <div className="space-y-6 pt-[3rem]">
      <div className="flex justify-between items-center">
        <h1 className="text-white text-2xl font-bold">Fraud Detection Map</h1>
        <div className="flex space-x-2">
          <button className="bg-slate-800/50 hover:bg-slate-700 text-white/80 px-3 py-1.5 rounded-lg text-sm">
            Last 24 Hours
          </button>
          <button className="bg-slate-800/50 hover:bg-slate-700 text-white/80 px-3 py-1.5 rounded-lg text-sm">
            Last Week
          </button>
          <button className="bg-teal-500/20 hover:bg-teal-500/30 text-teal-400 px-3 py-1.5 rounded-lg text-sm">
            Last Month
          </button>
        </div>
      </div>
      
      <div className="bg-slate-800/60 backdrop-blur-md rounded-xl p-6 h-96 flex items-center justify-center">
        
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-800/60 backdrop-blur-md rounded-xl p-6">
          <h2 className="text-white text-lg font-semibold mb-4">Fraud Hotspots</h2>
          <div className="space-y-4">
            {[
              { location: 'Moscow, Russia', incidents: 28, increase: '+12%' },
              { location: 'Lagos, Nigeria', incidents: 24, increase: '+8%' },
              { location: 'Jakarta, Indonesia', incidents: 19, increase: '+5%' },
              { location: 'Miami, USA', incidents: 16, increase: '+2%' },
              { location: 'London, UK', incidents: 12, increase: '-3%' },
            ].map((spot, index) => (
              <div key={index} className="flex justify-between items-center p-2 rounded-lg hover:bg-slate-700/30">
                <div>
                  <p className="text-white/90">{spot.location}</p>
                  <p className="text-xs text-white/60">{spot.incidents} incidents</p>
                </div>
                <span className={`text-sm ${spot.increase.startsWith('+') ? 'text-red-400' : 'text-teal-400'}`}>
                  {spot.increase}
                </span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-slate-800/60 backdrop-blur-md rounded-xl p-6">
          <h2 className="text-white text-lg font-semibold mb-4">Fraud Methods</h2>
          <div className="space-y-4">
            {[
              { method: 'Account Takeover', percentage: 32, color: 'bg-red-500' },
              { method: 'Identity Theft', percentage: 28, color: 'bg-orange-500' },
              { method: 'Phishing Attacks', percentage: 19, color: 'bg-yellow-500' },
              { method: 'Card Testing', percentage: 13, color: 'bg-teal-500' },
              { method: 'Money Laundering', percentage: 8, color: 'bg-blue-500' },
            ].map((method, index) => (
              <div key={index} className="space-y-1">
                <div className="flex justify-between text-sm">
                  <p className="text-white/90">{method.method}</p>
                  <p className="text-white/90">{method.percentage}%</p>
                </div>
                <div className="w-full bg-slate-700/50 rounded-full h-2">
                  <div className={`${method.color} h-2 rounded-full`} style={{ width: `${method.percentage}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
