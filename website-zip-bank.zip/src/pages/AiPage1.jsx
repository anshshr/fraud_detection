import React, { useState, useContext, useEffect } from "react";
import axios from "axios";
import { TransactionContext } from "../TransactionContext";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { motion, AnimatePresence } from "framer-motion";
import Lottie from "react-lottie";
// import * as dataAnalysisAnimation from "../animations/data-analysis.json";
// import * as machineAnalysisAnimation from "../animations/machine-learning.json";
// import * as aiAnalysisAnimation from "../animations/ai-processing.json";
import Otp from "./Otp";

const AiPage1 = () => {
  const { aiuser1, aiuser2, amount , otpsuc, setotpsuc } = useContext(TransactionContext);
  const [transactionPrediction, setTransactionPrediction] = useState(null);
  const [fraudPrediction, setFraudPrediction] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [stage, setStage] = useState(0); // 0: not started, 1: transaction model, 2: fraud model, 3: AI analysis
  const genAI = new GoogleGenerativeAI("AIzaSyC9Uzc1ZyQ3ve_AHqYtN6H8sk-n0wgpqmM");
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
  const [transactionData, setTransactionData] = useState(null);
  const [fraudData, setFraudData] = useState(null);
  const [detailedAnalysis, setDetailedAnalysis] = useState(null);
  const [parsedAnalysis, setParsedAnalysis] = useState(null);
const [showModal, setShowModal] = useState(false);
  // Animation options
  const defaultAnimationOptions = {
    loop: true,
    autoplay: true,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice"
    }
  };

  const dataAnimationOptions = {
    ...defaultAnimationOptions,
    // animationData: dataAnalysisAnimation
  };

  const mlAnimationOptions = {
    ...defaultAnimationOptions,
    // animationData: machineAnalysisAnimation
  };

  const aiAnimationOptions = {
    ...defaultAnimationOptions,
    // animationData: aiAnalysisAnimation
  };

  // Set Transaction Fraud Data
  useEffect(() => {
    if (aiuser1?.bankDetails?.balance !== undefined && aiuser2?.bankDetails?.balance !== undefined) {
      setTransactionData({
        step: "1",
        type: "4",
        amount: amount.toString(),
        oldbalanceOrg: aiuser1.bankDetails.balance,
        newbalanceOrig: aiuser1.bankDetails.balance - amount,
        oldbalanceDest: aiuser2.bankDetails.balance,
        newbalanceDest: aiuser2.bankDetails.balance + amount,
        balance_change_org: -amount,
        balance_change_dest: amount,
      });
    }
  }, [aiuser1, aiuser2, amount]);

  // Set Financial Fraud Data
  useEffect(() => {
    setFraudData({
      city_size: "2", 
      card_type: "0", 
      device: "1423", 
      channel: "2", 
      distance_from_home: "15", 
      transaction_hour: new Date().getHours().toString(),
      weekend_transaction: new Date().getDay() === 0 || new Date().getDay() === 6 ? "1" : "0", 
      year: new Date().getFullYear().toString(), 
      month: (new Date().getMonth() + 1).toString(), 
      day: new Date().getDate().toString(),
      hour: new Date().getHours().toString(),
      minute: new Date().getMinutes().toString(),
      second: new Date().getSeconds().toString(),
      microsecond: "0", 
      USD_converted_amount: amount?.toString(),
      is_bank_operating: "1", 
      merchant_category_label: "35.0"
    });
  }, [amount]);

  const handlePredict = async () => {
    if (!transactionData || !fraudData) {
      setError("Form data is not ready. Please check user details.");
      return;
    }

    setLoading(true);
    setError(null);
    setStage(1);
    setParsedAnalysis(null);
    setDetailedAnalysis(null);
    setTransactionPrediction(null);
    setFraudPrediction(null);

    try {
      // Fetch transaction fraud prediction
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate processing time
      const transactionResponse = await axios.post("http://localhost:5000/api/users/predict", transactionData);
      setTransactionPrediction(transactionResponse.data.prediction);
      setStage(2);

      // Fetch financial fraud prediction
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate processing time
      const fraudResponse = await axios.post("http://localhost:5000/api/users/financial-fraud-predict", fraudData);
      setFraudPrediction(fraudResponse.data.prediction);
      
      // If both models predict fraud, proceed to AI analysis
      if (transactionResponse.data.prediction === 1 || fraudResponse.data.prediction === 1) {
        await handleAIAnalysis();
      } else {
        setLoading(false);
      }
    } catch (err) {
      setError(`Error fetching prediction: ${err.message}`);
      setLoading(false);
    }
  };

  const handleAIAnalysis = async () => {
    setStage(3);
    
    const currentDate = new Date();

    const requestData = {
      transaction_analysis: {
        report_summary:
          "This report assesses the risk associated with a financial transaction, considering both transactional details and contextual factors.",
        risk_evaluation: {
          overall_risk_score: "68%",
          risk_factors: [
            {
              factor: "Significant Balance Alteration",
              description:
                "The transaction resulted in a notable percentage decrease in the origin account's balance and a corresponding increase in the destination account's balance.",
              risk_impact: "75%",
              relevant_data: {
                transfer_amount: amount,
                origin_account_initial: aiuser1.bankDetails.balance,
                origin_account_final: aiuser1.bankDetails.balance - amount,
                destination_account_initial: aiuser2.bankDetails.balance,
                destination_account_final: aiuser2.bankDetails.balance + amount,
                origin_balance_change_percent:
                  ((amount / aiuser1.bankDetails.balance) * 100).toFixed(2) + "%",
                destination_balance_change_percent:
                  ((amount / aiuser2.bankDetails.balance) * 100).toFixed(2) + "%",
              },
            },
            {
              factor: "Transaction Classification and Stage",
              description:
                "The transaction type and step codes (4 and 1, respectively) provide crucial information about the nature and stage of the transaction.",
              risk_impact: "45%",
              relevant_data: {
                transaction_type_code: "4",
                transaction_stage: "1",
              },
            },
            {
              factor: "Pre-calculated Fraud Probability",
              description:
                "The 'predection_store' value of 0.5 suggests a moderate level of pre-calculated risk.",
              risk_impact: "70%",
              relevant_data: {
                fraud_probability_score: "0.5",
              },
            },
          ],
        },
        transaction_details: {
          transaction_data: {
            step: "1",
            type: "4",
            amount: amount,
            oldbalanceOrg: aiuser1.bankDetails.balance,
            newbalanceOrig: aiuser1.bankDetails.balance - amount,
            oldbalanceDest: aiuser2.bankDetails.balance,
            newbalanceDest: aiuser2.bankDetails.balance + amount,
            balance_change_org: -amount,
            balance_change_dest: amount,
            city_size: "2",
            card_type: "0",
            device_id: "1423",
            channel_used: "2",
            distance_from_home: "15",
            transaction_hour: currentDate.getHours().toString(),
            weekend_transaction: currentDate.getDay() === 0 || currentDate.getDay() === 6 ? "1" : "0",
            year: currentDate.getFullYear().toString(),
            month: (currentDate.getMonth() + 1).toString(),
            day: currentDate.getDate().toString(),
            hour: currentDate.getHours().toString(),
            minute: currentDate.getMinutes().toString(),
            second: currentDate.getSeconds().toString(),
            microsecond: "0",
            USD_converted_amount: amount.toString(),
            is_bank_operating: "1",
            merchant_category_label: "35.0",
          },
        },
      },
    };

    try {
      await new Promise(resolve => setTimeout(resolve, 3000)); // Simulate AI processing time
      const response = await model.generateContent({
        contents: [{ role: "user", parts: [{ text: JSON.stringify(requestData) }] }],
      });

      const rawText = response.response.candidates[0].content.parts[0].text;
      setDetailedAnalysis(rawText);
      
      // Parse the analysis for formatted display
      parseAnalysisText(rawText);
      
    } catch (err) {
      setError(`Error fetching AI analysis: ${err.message}`);
      console.error("API Response Error:", err);
    } finally {
      setLoading(false);
      setStage(0);
    }
  };

  const parseAnalysisText = (text) => {
    // Sample text parsing - to be replaced with real API response parsing
    const mockAnalysis = {
      overview: {
        title: "Transaction Analysis Report",
        riskScore: "68%",
        summary: "This transaction has been flagged as high-risk due to multiple suspicious factors."
      },
      highRiskFactors: [
        {
          name: "Significant Balance Alteration",
          impact: "75%",
          description: "The transaction resulted in the origin account going from a positive balance to a negative balance."
        },
        {
          name: "Pre-calculated Fraud Probability",
          impact: "70%",
          description: "A pre-calculated fraud probability score of 0.5 indicates a moderate to high likelihood of fraudulent activity."
        }
      ],
      moderateRiskFactors: [
        {
          name: "Transaction Classification and Stage",
          impact: "45%",
          description: "The transaction type code (4) and stage (1) add to the overall risk assessment."
        }
      ],
      concerningDetails: [
        "Large Transfer Amount: $" + amount + " is significant given account balances",
        "Negative Origin Balance: The origin account ends with a negative balance",
        "Small Destination Balance Change Percentage: Unusual for such a transfer",
        "Transaction Time: Early morning transaction (higher risk period)",
        "Weekend Transaction: Occurred during weekend (higher fraud rates)"
      ],
      recommendations: [
        "Immediate Investigation: This transaction requires urgent review",
        "Contact Origin Account Holder: Verify transaction authorization",
        "Review Transaction Type and Stage Codes: Clarify their contribution",
        "Enhanced Fraud Detection: Refine the fraud detection system",
        "Security Audit: Check for vulnerabilities"
      ]
    };
    
    setParsedAnalysis(mockAnalysis);
  };






  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
        const response = await axios.post("http://localhost:5000/api/users/transactions", {
          sender: aiuser1._id, // Sender's User ID
        receiver: aiuser2._id, // Receiver's User ID
        amount: amount,
        senderImageUrl: aiuser1.personalDetails.imageUrl,
        receiverImageUrl: aiuser2.personalDetails.imageUrl,
        senderLocation: aiuser1.personalDetails.address.city,
        receiverLocation: aiuser2.personalDetails.address.city,
        });
        alert("✅ Transaction Successful!");
        console.log(response.data);
        setotpsuc(false);
        
    } catch (error) {
        alert("❌ Transaction Failed: " + (error.response?.data?.message || "Server error"));
        console.error("Transaction Error:", error);
    }
};

  return (
    <div className="min-h-screen bg-gradient-to-br pt-[6rem] from-gray-900 to-gray-800 text-white pb-20">
      {/* Matrix-style background animation */}

      {showModal && <Otp setShowModal={setShowModal} />}
      <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-10">
        <div className="code-rain">
          {Array.from({ length: 20 }).map((_, i) => (
            <div key={i} className="code-column" style={{ animationDelay: `${i * 0.1}s` }}>
              {Array.from({ length: 40 }).map((_, j) => (
                <span key={j} className="code-character" style={{ animationDelay: `${Math.random() * 5}s` }}>
                  {String.fromCharCode(33 + Math.floor(Math.random() * 94))}
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* Header */}
      <header className="relative z-10 pt-8 pb-6">
        <div className="max-w-6xl mx-auto px-6">
          <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
            Fraud Detection System
          </h1>
          <p className="mt-2 text-gray-300 max-w-2xl">
            Advanced AI-powered analysis to detect potentially fraudulent transactions in real-time
          </p>
        </div>
      </header>

      {/* Main content */}
      <main className="relative z-10 max-w-6xl mx-auto px-6">
        {/* Transaction details card */}

      
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="backdrop-blur-md bg-white/10 p-6 rounded-2xl shadow-xl border border-white/20 mb-8"
        >
          <h2 className="text-xl font-semibold text-cyan-300 mb-4">Transaction Details</h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Sender:</span>
                <span className="font-medium">{aiuser1?.name || "Unknown"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Initial Balance:</span>
                <span className="font-medium">${aiuser1?.bankDetails?.balance.toLocaleString() || "0"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Final Balance:</span>
                <span className={`font-medium ${aiuser1?.bankDetails?.balance - amount < 0 ? 'text-red-400' : 'text-green-400'}`}>
                  ${(aiuser1?.bankDetails?.balance - amount).toLocaleString() || "0"}
                </span>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Recipient:</span>
                <span className="font-medium">{aiuser2?.name || "Unknown"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Initial Balance:</span>
                <span className="font-medium">${aiuser2?.bankDetails?.balance.toLocaleString() || "0"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Final Balance:</span>
                <span className="font-medium text-green-400">
                  ${(aiuser2?.bankDetails?.balance + amount).toLocaleString() || "0"}
                </span>
              </div>
            </div>
          </div>
          
          <div className="mt-4 pt-4 border-t border-white/10">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Transfer Amount:</span>
              <span className="text-xl font-bold text-white">${amount ? amount.toLocaleString() : "0"}</span>
            </div>
          </div>

          {/*  */}
          {
            (fraudPrediction === 1 || transactionPrediction === 1) &&  ( <div className="w-full flex justify-center items-center mt-6 h-[6rem]">
               <motion.button 
                       onClick={() => setShowModal(true)}
                       className="px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold shadow-lg hover:bg-purple-700 transition-all duration-300"
                       whileHover={{ scale: 1.05 }}
                       whileTap={{ scale: 0.95 }}
                     >
                       Secure Login with OTP
                     </motion.button>
                </div>)

                   }

                   {
                    (otpsuc==true) && ( <div className="w-full flex justify-center items-center mt-6 h-[6rem]">
               <motion.button 
                       onClick={(e) => handleSubmit(e)}
                       className="px-6 py-3 bg-green-600 text-white rounded-lg font-semibold shadow-lg hover:bg-green-700 transition-all duration-300"
                       whileHover={{ scale: 1.05 }}
                       whileTap={{ scale: 0.95 }}
                     >
                       Send Money Now
                     </motion.button>
                </div>)
                   }
        </motion.div>

        {/* Analysis Button */}
        <div className="flex justify-center mb-8">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handlePredict}
            disabled={loading}
            className={`relative overflow-hidden px-8 py-4 rounded-lg font-bold text-lg shadow-lg ${
              loading 
                ? "bg-gray-700 cursor-not-allowed" 
                : "bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600"
            }`}
          >
            <span className="relative z-10">
              {loading ? "Analysis in Progress..." : "Begin Fraud Analysis"}
            </span>
            {!loading && (
              <motion.div 
                className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 opacity-0"
                animate={{ opacity: [0, 0.5, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
            )}
          </motion.button>
        </div>

        {/* Analysis Timeline */}
        {loading && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="backdrop-blur-md bg-white/10 p-6 rounded-2xl shadow-xl border border-white/20 mb-8"
          >
            <h2 className="text-xl font-semibold text-cyan-300 mb-4">Analysis Progress</h2>
            
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-gray-700 transform -translate-x-1/2"></div>
              
              {/* Step 1: Transaction Fraud Model */}
              <div className="relative mb-16">
                <div className={`absolute left-1/2 top-0 w-8 h-8 rounded-full transform -translate-x-1/2 flex items-center justify-center ${
                  stage >= 1 ? "bg-cyan-500" : "bg-gray-700"
                }`}>
                  {stage > 1 ? (
                    <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  ) : stage === 1 ? (
                    <div className="w-2 h-2 bg-white rounded-full animate-ping"></div>
                  ) : (
                    <span className="text-xs text-gray-400">1</span>
                  )}
                </div>
                
                <div className="ml-12 md:ml-0 md:grid md:grid-cols-2 gap-8">
                  <div className={`md:text-right md:pr-16 transition-opacity ${stage !== 1 ? "opacity-50" : "opacity-100"}`}>
                    <h3 className="text-lg font-medium text-cyan-300">Transaction Fraud Model</h3>
                    <p className="text-gray-400 mt-1">Analyzing transaction patterns and account behaviors</p>
                  </div>
                  <div className={`mt-4 md:mt-0 transition-opacity ${stage !== 1 ? "opacity-0" : "opacity-100"}`}>
                    <div className="w-40 h-40 mx-auto">
                      <Lottie options={dataAnimationOptions} />
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Step 2: Financial Fraud Model */}
              <div className="relative mb-16">
                <div className={`absolute left-1/2 top-0 w-8 h-8 rounded-full transform -translate-x-1/2 flex items-center justify-center ${
                  stage >= 2 ? "bg-cyan-500" : "bg-gray-700"
                }`}>
                  {stage > 2 ? (
                    <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  ) : stage === 2 ? (
                    <div className="w-2 h-2 bg-white rounded-full animate-ping"></div>
                  ) : (
                    <span className="text-xs text-gray-400">2</span>
                  )}
                </div>
                
                <div className="ml-12 md:ml-0 md:grid md:grid-cols-2 gap-8">
                  <div className={`md:text-right md:pr-16 transition-opacity ${stage !== 2 ? "opacity-50" : "opacity-100"}`}>
                    <h3 className="text-lg font-medium text-cyan-300">Financial Fraud Model</h3>
                    <p className="text-gray-400 mt-1">Evaluating contextual factors and financial risk indicators</p>
                  </div>
                  <div className={`mt-4 md:mt-0 transition-opacity ${stage !== 2 ? "opacity-0" : "opacity-100"}`}>
                    <div className="w-40 h-40 mx-auto">
                      <Lottie options={mlAnimationOptions} />
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Step 3: AI Deep Analysis */}
              <div className="relative">
                <div className={`absolute left-1/2 top-0 w-8 h-8 rounded-full transform -translate-x-1/2 flex items-center justify-center ${
                  stage >= 3 ? "bg-cyan-500" : "bg-gray-700"
                }`}>
                  {stage > 3 ? (
                    <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  ) : stage === 3 ? (
                    <div className="w-2 h-2 bg-white rounded-full animate-ping"></div>
                  ) : (
                    <span className="text-xs text-gray-400">3</span>
                  )}
                </div>
                
                <div className="ml-12 md:ml-0 md:grid md:grid-cols-2 gap-8">
                  <div className={`md:text-right md:pr-16 transition-opacity ${stage !== 3 ? "opacity-50" : "opacity-100"}`}>
                    <h3 className="text-lg font-medium text-cyan-300">AI Deep Analysis</h3>
                    <p className="text-gray-400 mt-1">Performing comprehensive risk assessment and generating detailed report</p>
                  </div>
                  <div className={`mt-4 md:mt-0 transition-opacity ${stage !== 3 ? "opacity-0" : "opacity-100"}`}>
                    <div className="w-40 h-40 mx-auto">
                      <Lottie options={aiAnimationOptions} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Results section */}
        <AnimatePresence>
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="backdrop-blur-md bg-red-500/20 p-4 rounded-lg border border-red-500/40 mb-8"
            >
              <p className="text-red-300">{error}</p>
            </motion.div>
          )}

          {/* Initial Model Results */}
          {(transactionPrediction !== null || fraudPrediction !== null) && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="backdrop-blur-md bg-white/10 p-6 rounded-2xl shadow-xl border border-white/20 mb-8"
            >
              <h2 className="text-xl font-semibold text-cyan-300 mb-4">Initial Detection Results</h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                {transactionPrediction !== null && (
                  <div className={`p-4 rounded-xl ${
                    transactionPrediction === 1 
                      ? "bg-gradient-to-br from-red-900/40 to-red-700/40 border border-red-500/30" 
                      : "bg-gradient-to-br from-green-900/40 to-green-700/40 border border-green-500/30"
                  }`}>
                    <h3 className="text-lg font-medium mb-2">Transaction Fraud</h3>
                    <div className="flex items-center">
                      {transactionPrediction === 1 ? (
                        <>
                          <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                            </svg>
                          </div>
                          <div>
                            <p className="text-xl font-bold text-red-300">Fraudulent</p>
                            <p className="text-gray-400 text-sm">High-risk transaction pattern detected</p>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                            </svg>
                          </div>
                          <div>
                            <p className="text-xl font-bold text-green-300">Legitimate</p>
                            <p className="text-gray-400 text-sm">No suspicious transaction patterns</p>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                )}
                
                {fraudPrediction !== null && (
                  <div className={`p-4 rounded-xl ${
                    fraudPrediction === 1 
                      ? "bg-gradient-to-br from-red-900/40 to-red-700/40 border border-red-500/30" 
                      : "bg-gradient-to-br from-green-900/40 to-green-700/40 border border-green-500/30"
                  }`}>
                    <h3 className="text-lg font-medium mb-2">Financial Fraud</h3>
                    <div className="flex items-center">
                      {fraudPrediction === 1 ? (
                        <>
                          <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                            </svg>
                          </div>
                          <div>
                            <p className="text-xl font-bold text-red-300">Fraudulent</p>
                            <p className="text-gray-400 text-sm">Suspicious financial indicators detected</p>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                            </svg>
                          </div>
                          <div>
                            <p className="text-xl font-bold text-green-300">Legitimate</p>
                            <p className="text-gray-400 text-sm">Financial indicators appear normal</p>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>
                   
              
             
            </motion.div>
          )}

          {/* AI Detailed Analysis */}
          {parsedAnalysis && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="backdrop-blur-md bg-white/10 p-6 rounded-2xl shadow-xl border border-white/20"
            >
              <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
                  {parsedAnalysis.overview.title}
                </h2>
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full bg-red-500/30 flex items-center justify-center text-xl font-bold text-white">
                    {parsedAnalysis.overview.riskScore}
                  </div>
                </div>
              </div>
              
              <p className="text-gray-300 mb-6">{parsedAnalysis.overview.summary}</p>
              
              {/* Risk Factors Section */}
              <div className="space-y-8">
                {/* High Risk Factors */}
                <div>
                  <h3 className="text-xl font-medium text-red-400 mb-3">High-Risk Factors</h3>
                  <div className="space-y-4">
                    {parsedAnalysis.highRiskFactors.map((factor, index) => (
                      <div key={index} className="p-4 rounded-lg bg-red-900/20 border border-red-500/30">
                        <div className="flex justify-between items-center mb-2">
                          <h4 className="font-medium">{factor.name}</h4>
                          <span className="px-2 py-1 bg-red-500/40 rounded-full text-sm">
                            {factor.impact} Impact
                          </span>
                        </div>
                        <p className="text-gray-300 text-sm">{factor.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Moderate Risk Factors */}
                <div>
                  <h3 className="text-xl font-medium text-yellow-400 mb-3">Moderate-Risk Factors</h3>
                  <div className="space-y-4">
                    {parsedAnalysis.moderateRiskFactors.map((factor, index) => (
                      <div key={index} className="p-4 rounded-lg bg-yellow-900/20 border border-yellow-500/30">
                        <div className="flex justify-between items-center mb-2">
                          <h4 className="font-medium">{factor.name}</h4>
                          <span className="px-2 py-1 bg-yellow-500/40 rounded-full text-sm">
                            {factor.impact} Impact
                          </span>
                        </div>
                        <p className="text-gray-300 text-sm">{factor.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Concerning Transaction Details */}
                <div>
                  <h3 className="text-xl font-medium text-cyan-300 mb-3">Concerning Transaction Details</h3>
                  <div className="p-4 rounded-lg bg-cyan-900/20 border border-cyan-500/30">
                    <ul className="space-y-2">
                      {parsedAnalysis.concerningDetails.map((detail, index) => (
                        <li key={index} className="flex items-start">
                          <svg className="w-5 h-5 text-cyan-400 mr-2 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10" strokeWidth="2" />
                            <path d="M12 8v4M12 16h.01" strokeWidth="2" strokeLinecap="round" />
                          </svg>
                          <span className="text-gray-300">{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                {/* Recommendations */}
                <div>
                  <h3 className="text-xl font-medium text-purple-400 mb-3">Recommendations</h3>
                  <div className="p-4 rounded-lg bg-purple-900/20 border border-purple-500/30">
                    <ul className="space-y-2">
                      {parsedAnalysis.recommendations.map((rec, index) => (
                        <li key={index} className="flex items-start">
                          <svg className="w-5 h-5 text-purple-400 mr-2 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                          </svg>
                          <span className="text-gray-300">{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
              
              {/* Raw Analysis Toggle */}
              <div className="mt-8 pt-4 border-t border-white/10">
                <button 
                  onClick={() => setDetailedAnalysis(detailedAnalysis ? null : "raw analysis text here")}
                  className="text-cyan-400 hover:text-cyan-300 text-sm flex items-center"
                >
                  {detailedAnalysis ? "Hide" : "Show"} Raw Analysis
                  <svg className={`w-4 h-4 ml-1 transform ${detailedAnalysis ? "rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                
                {detailedAnalysis && (
                  <div className="mt-4 p-4 bg-gray-900/50 rounded-lg overflow-auto max-h-96 text-gray-400 text-sm font-mono">
                    <pre>{detailedAnalysis}</pre>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* CSS for Matrix-style animation */}
     
    </div>
  );
};

export default AiPage1;