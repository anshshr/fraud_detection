import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  CreditCard, 
  DollarSign, 
  Clock, 
  Send, 
  Menu, 
  X, 
  MessageSquare, 
  History, 
  User, 
  Mail, 
  Phone, 
  Home, 
  File
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useParams } from 'react-router-dom';

const UserDashboard = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('transactions');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentRecipient, setPaymentRecipient] = useState('');
  const [transactions, setTransactions] = useState([]);
  const { id } = useParams();
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        setLoading(true);
        // Replace with your actual API endpoint
        const response = await axios.get(`http://localhost:5000/api/users/users/${id}`);
        setUser(response.data);
        console.log(response.data);
        setLoading(false);
      } catch (err) {
        setError('Failed to load user data');
        setLoading(false);
        console.error(err);
      }
    };



    const getTransactionsByUserId = async (userId) => {
  try {
    const response = await axios.get(`http://localhost:5000/api/users/transactions/${userId}`);
    setTransactions(response.data.reverse()); // Returns the transaction list
  } catch (error) {
    console.error("Error fetching transactions:", error.response?.data || error.message);
    throw error;
  }
};
getTransactionsByUserId("67e886bafbf909a686e608af");
    fetchUserData();
  }, []);

  // Mock transaction data (this would come from your API)
//   const transactions = [
//     { id: 1, type: 'debit', amount: 250.00, recipient: 'Electric Company', date: '2025-03-29', status: 'completed' },
//     { id: 2, type: 'credit', amount: 1250.00, recipient: 'Salary Deposit', date: '2025-03-28', status: 'completed' },
//     { id: 3, type: 'debit', amount: 85.75, recipient: 'Grocery Store', date: '2025-03-27', status: 'completed' },
//     { id: 4, type: 'debit', amount: 125.00, recipient: 'Internet Provider', date: '2025-03-26', status: 'pending' },
//   ];

  // Mock messages data (this would come from your API)
  const messages = [
    { id: 1, sender: 'System', content: 'Welcome to your banking dashboard', timestamp: '2025-03-30T09:00:00' },
    { id: 2, sender: 'Support Team', content: 'Your last payment was processed successfully', timestamp: '2025-03-29T14:30:00' },
    { id: 3, sender: 'Security', content: 'New login detected on your account', timestamp: '2025-03-28T18:45:00' },
  ];

  const handlePaymentSubmit = async (e) => {
    e.preventDefault();
    // This would be an actual API call in a real application
    console.log('Payment submitted:', { amount: paymentAmount, recipient: paymentRecipient });
    // Close modal after submission
    setShowPaymentModal(false);
    setPaymentAmount('');
    setPaymentRecipient('');
  };

  if (loading) return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-400"></div>
    </div>
  );

  if (error) return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900 text-white">
      <div className="text-red-400">{error}</div>
    </div>
  );

  // Demo user data - in a real app, this would come from your API
  const demoUser = {
    name: "John Doe",
    email: "john.doe@example.com",
    role: "customer",
    personalDetails: {
      dateOfBirth: "1990-05-15",
      phoneNumber: "+1 (555) 123-4567",
      address: {
        street: "123 Main Street",
        city: "Anytown",
        state: "CA",
        zipCode: "12345",
        country: "USA"
      }
    },
    bankDetails: {
      accountNumber: "XXXX-XXXX-XXXX-1234",
      ifscCode: "BANK0001234",
      balance: 12450.75
    }
  };

  const userData = user||demoUser;

  return (
    <div className="min-h-screen pt-[3rem] bg-gray-900 text-white">
      {/* Main Content */}
      <div className="flex h-screen">
        {/* Sidebar Overlay */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          ></div>
        )}

        {/* Sidebar */}
        <div className={`fixed lg:relative lg:block lg:w-64 w-64 h-full z-30 bg-gray-800 bg-opacity-60 backdrop-blur-lg transition-all duration-300 ease-in-out border-r border-gray-700 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
          <div className="p-4 flex justify-between items-center border-b border-gray-700">
            <h2 className="text-xl font-bold text-green-400">Banking App</h2>
            <button onClick={() => setSidebarOpen(false)} className="lg:hidden">
              <X className="h-6 w-6 text-gray-400" />
            </button>
          </div>
          
          <div className="p-4">
            <div className="flex flex-col items-center py-4 mb-6">
             
              <img src={userData?.imageUrl} alt="" className="h-20 w-20 rounded-full bg-gradient-to-r from-green-500 to-green-300 flex items-center justify-center text-2xl font-bold mb-3"/>
              <h3 className="font-bold text-lg">{userData.name}</h3>
              <p className="text-gray-400 text-sm">{userData.email}</p>
            </div>

            <div className="space-y-1 mb-6">
              <button
                onClick={() => setActiveTab('transactions')}
                className={`w-full flex items-center p-3 rounded-lg text-left transition-colors ${activeTab === 'transactions' ? 'bg-green-500 bg-opacity-20 text-green-400' : 'hover:bg-gray-700'}`}
              >
                <History className="mr-3 h-5 w-5" />
                Transactions
              </button>
              <button
                onClick={() => setActiveTab('messages')}
                className={`w-full flex items-center p-3 rounded-lg text-left transition-colors ${activeTab === 'messages' ? 'bg-green-500 bg-opacity-20 text-green-400' : 'hover:bg-gray-700'}`}
              >
                <MessageSquare className="mr-3 h-5 w-5" />
                Messages
              </button>
              <button
                onClick={() => setActiveTab('profile')}
                className={`w-full flex items-center p-3 rounded-lg text-left transition-colors ${activeTab === 'profile' ? 'bg-green-500 bg-opacity-20 text-green-400' : 'hover:bg-gray-700'}`}
              >
                <User className="mr-3 h-5 w-5" />
                Profile
              </button>
            </div>
          </div>
        </div>

        {/* Main Dashboard Area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="h-16 flex items-center justify-between px-6 bg-gray-800 bg-opacity-60 backdrop-blur-lg border-b border-gray-700">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden">
              <Menu className="h-6 w-6 text-gray-400" />
            </button>
            <div className="flex items-center space-x-3">
              <Link  to="/userdashboard/userpaymentdashboard"
                onClick={() => setShowPaymentModal(true)}
                className="bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-lg flex items-center transition-colors"
              >
                <Send className="mr-2 h-4 w-4" /> Make Payment
              </Link>
            </div>
          </header>

          {/* Dashboard Content */}
          <main className="flex-1 overflow-y-auto bg-gradient-to-br from-gray-900 to-gray-800 p-6">
            {/* Account Summary Card */}
            <div className="mb-8 bg-gray-800 bg-opacity-50 backdrop-blur-lg rounded-xl border border-gray-700 overflow-hidden shadow-lg">
              <div className="p-6">
                <h2 className="font-bold text-xl mb-4">Account Overview</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-gray-700 bg-opacity-40 rounded-lg p-5">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-gray-400">Current Balance</h3>
                      <DollarSign className="h-5 w-5 text-green-400" />
                    </div>
                    <p className="text-2xl font-bold text-green-400">${userData?.bankDetails?.balance}</p>
                  </div>

                  <div className="bg-gray-700 bg-opacity-40 rounded-lg p-5">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-gray-400">Account Number</h3>
                      <CreditCard className="h-5 w-5 text-green-400" />
                    </div>
                    <p className="text-lg font-medium">{userData.bankDetails.accountNumber}</p>
                  </div>

                  <div className="bg-gray-700 bg-opacity-40 rounded-lg p-5">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-gray-400">IFSC Code</h3>
                      <File className="h-5 w-5 text-green-400" />
                    </div>
                    <p className="text-lg font-medium">{userData.bankDetails.ifscCode}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Tab Content */}
            <div className="bg-gray-800 bg-opacity-50 backdrop-blur-lg rounded-xl border border-gray-700 overflow-hidden shadow-lg">
            {activeTab === 'transactions' && (
  <div className="p-6">
    <div className="flex justify-between items-center mb-6">
      <h2 className="font-bold text-xl text-green-400">Recent Transactions</h2>
      <div>
        <select className="bg-gray-700 bg-opacity-50 border border-gray-600 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-400">
          <option>All Transactions</option>
          <option>Incoming</option>
          <option>Outgoing</option>
        </select>
      </div>
    </div>
    
    <div className="space-y-4">
      {transactions.map(transaction => (
        <div key={transaction._id} className="bg-gray-800 bg-opacity-30 backdrop-blur-sm rounded-xl border border-gray-700 overflow-hidden hover:border-green-400 transition-colors">
          <div className="p-4">
            <div className="flex justify-between items-start mb-3">
              <div className="flex items-center">
                {/* Profile image or placeholder */}
                <div className="h-10 w-10 rounded-full bg-gray-700 flex items-center justify-center mr-3 overflow-hidden">
                  {transaction.senderImageUrl ? (
                    <img src={transaction.senderImageUrl} alt={transaction.senderName} className="h-full w-full object-cover" />
                  ) : (
                    <User className="h-5 w-5 text-gray-400" />
                  )}
                </div>
                
                <div>
                  <div className="flex items-center">
                    <p className="font-medium">{transaction.senderName}</p>
                    <span className="mx-2 text-gray-500">→</span>
                    <p className="font-medium">{transaction.receiverName}</p>
                  </div>
                  <div className="flex items-center text-xs text-gray-400 mt-1">
                    <div className="flex items-center mr-3">
                      <Clock className="h-3 w-3 mr-1" />
                      {new Date(transaction.createdAt).toLocaleDateString()}
                    </div>
                    <div className="flex items-center">
                      <Home className="h-3 w-3 mr-1" />
                      {transaction.location.senderLocation} → {transaction.location.receiverLocation}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <p className="text-lg font-bold">${transaction.amount.toFixed(2)}</p>
                <div className="mt-1">
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    transaction.status === 'safe' 
                      ? 'bg-green-500 bg-opacity-20 text-green-400' 
                      : transaction.status === 'fraud-alert'
                        ? 'bg-red-500 bg-opacity-20 text-red-400'
                        : 'bg-yellow-500 bg-opacity-20 text-yellow-400'
                  }`}>
                    {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1).replace('-', ' ')}
                  </span>
                </div>
              </div>
            </div>
            
            {transaction.fraudScore > 0 && (
              <div className="mt-2 pt-2 border-t border-gray-700">
                <div className="flex items-center justify-between">
                  <p className="text-xs text-gray-400">Fraud Risk Score</p>
                  <div className="w-32 h-2 bg-gray-700 rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${
                        transaction.fraudScore < 30 
                          ? 'bg-green-400' 
                          : transaction.fraudScore < 70 
                            ? 'bg-yellow-400' 
                            : 'bg-red-400'
                      }`} 
                      style={{ width: `${transaction.fraudScore}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            )}
            
            {transaction.frequency > 1 && (
              <div className="mt-1 text-xs text-gray-400 flex items-center">
                <span className="mr-1">Transaction frequency:</span>
                <span className="font-medium">{transaction.frequency}x</span>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  </div>
)}

              {activeTab === 'messages' && (
                <div className="p-6">
                  <h2 className="font-bold text-xl mb-4">Messages</h2>
                  <div className="space-y-4">
                    {messages.map(message => (
                      <div key={message.id} className="bg-gray-700 bg-opacity-30 rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-medium">{message.sender}</h3>
                          <span className="text-xs text-gray-400">
                            {new Date(message.timestamp).toLocaleString()}
                          </span>
                        </div>
                        <p className="text-gray-300">{message.content}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'profile' && (
                <div className="p-6">
                  <h2 className="font-bold text-xl mb-4">Profile Information</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-gray-700 bg-opacity-30 rounded-lg p-4">
                      <h3 className="text-green-400 font-medium mb-3">Personal Details</h3>
                      <div className="space-y-3">
                        <div className="flex items-center">
                          <User className="h-4 w-4 mr-3 text-gray-400" />
                          <span className="text-gray-400 mr-2">Name:</span>
                          <span>{userData.name}</span>
                        </div>
                        <div className="flex items-center">
                          <Mail className="h-4 w-4 mr-3 text-gray-400" />
                          <span className="text-gray-400 mr-2">Email:</span>
                          <span>{userData.email}</span>
                        </div>
                        <div className="flex items-center">
                          <Phone className="h-4 w-4 mr-3 text-gray-400" />
                          <span className="text-gray-400 mr-2">Phone:</span>
                          <span>{userData.personalDetails.phoneNumber}</span>
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-3 text-gray-400" />
                          <span className="text-gray-400 mr-2">DOB:</span>
                          <span>{new Date(userData.personalDetails.dateOfBirth).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>
                    <div className="bg-gray-700 bg-opacity-30 rounded-lg p-4">
                      <h3 className="text-green-400 font-medium mb-3">Address</h3>
                      <div className="flex items-start">
                        <Home className="h-4 w-4 mr-3 mt-1 text-gray-400" />
                        <div>
                          <p>{userData.personalDetails.address.street}</p>
                          <p>{userData.personalDetails.address.city}, {userData.personalDetails.address.state} {userData.personalDetails.address.zipCode}</p>
                          <p>{userData.personalDetails.address.country}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </main>
        </div>
      </div>

      {/* Payment Modal */}
    
    </div>
  );
};

export default UserDashboard;