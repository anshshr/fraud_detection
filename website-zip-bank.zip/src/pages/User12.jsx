import React, { useState ,useEffect } from 'react';
import { 
  Shield, 
  AlertTriangle, 
  Clock, 
  MapPin, 
  FileText, 
  DollarSign, 
  Zap,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { useParams } from 'react-router-dom';
import { db } from '../firebase/firebase';
import { collection, query, where, getDocs } from "firebase/firestore";
import Loader from '../components/Loader';

const User12 = () => {
  const [expandedFactor, setExpandedFactor] = useState(null);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const { userId } = useParams();

  const toggleFactor = (index) => {
    setExpandedFactor(expandedFactor === index ? null : index);
  };

  useEffect(() => {
    const fetchTransactions = async () => {
      setLoading(true);
      try {
        console.log("Fetching transactions for user:", userId);

        const transactionsReportCollection = collection(db, "transactions_report");
        const q = query(transactionsReportCollection, where("transaction_analysis.user_id", "==", userId));
        const querySnapshot = await getDocs(q);

        if (!querySnapshot.empty) {
          const doc = querySnapshot.docs[0]; // Get the first document
          setData({ id: doc.id, ...doc.data() });
          console.log("Transaction report found:", doc.data());
        } else {
          console.log("No transaction report found for this user ID.");
          setData(null);
        }
      } catch (error) {
        console.error("Error fetching transaction report:", error);
        setData(null);
      }
      setLoading(false);
    };

    if (userId) {
      fetchTransactions();
    }
  }, [userId]);

  // Icons for risk factors with different colors
  const factorIcons = [
    <DollarSign className="text-emerald-500" size={24} />,
    <Clock className="text-blue-400" size={24} />,
    <FileText className="text-purple-400" size={24} />,
    <AlertTriangle className="text-amber-400" size={24} />
  ];

  // Risk impact color mapper
  const getRiskColor = (impact) => {
    const percent = parseInt(impact);
    if (percent >= 70) return "from-red-500 to-red-600";
    if (percent >= 50) return "from-amber-500 to-amber-600";
    return "from-emerald-500 to-emerald-600";
  };

  // if(loading) return <div>Loading...</div>

  return (
    <div className="min-h-screen  pt-[8rem] bg-gradient-to-br from-gray-900 to-gray-800 text-white p-6">
      {
                loading ? <Loader/> : data ? (

                  <div className="w-[85vw]  mx-auto">
        {/* Header */}
        <div className="backdrop-blur-md bg-white/10 rounded-lg p-6 border border-white/20 shadow-xl mb-6">

      
          <div className="flex items-center justify-between">


            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Transaction Risk Analysis</h1>
             
              <p className="text-gray-300">{data.transaction_analysis.report_summary}</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="text-xl font-bold text-white">Overall Risk</div>
                <div className="relative h-24 w-24">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-2xl font-bold text-white">{data.transaction_analysis.risk_evaluation.overall_risk_score}</span>
                  </div>
                  <svg className="h-24 w-24" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="none"
                      stroke="rgba(255,255,255,0.2)"
                      strokeWidth="8"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="none"
                      stroke="url(#risk-gradient)"
                      strokeWidth="8"
                      strokeDasharray="283"
                      strokeDashoffset={283 - (parseInt(data.transaction_analysis.risk_evaluation.overall_risk_score) / 100) * 283}
                      transform="rotate(-90 50 50)"
                    />
                    <defs>
                      <linearGradient id="risk-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#10B981" />
                        <stop offset="50%" stopColor="#F59E0B" />
                        <stop offset="100%" stopColor="#EF4444" />
                      </linearGradient>
                    </defs>
                  </svg>
                </div>
              </div>
              <Shield size={64} className="text-blue-400" />
            </div>
          </div>
        </div>

        {/* Main content grid */}
        <div className="grid w-[85vw]   grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left column - Risk Factors */}
          <div className="lg:col-span-2 space-y-4">
            <h2 className="text-2xl font-bold text-white mb-4">Risk Factors</h2>
            
            {data.transaction_analysis.risk_evaluation.risk_factors.map((factor, index) => (
              <div 
                key={index} 
                className="backdrop-blur-md bg-white/10 rounded-lg border border-white/20 shadow-xl overflow-hidden transition-all duration-300 hover:bg-white/15"
              >
                <div 
                  className="p-4 flex items-center justify-between cursor-pointer"
                  onClick={() => toggleFactor(index)}
                >
                  <div className="flex items-center gap-3">
                    {factorIcons[index]}
                    <div>
                      <h3 className="font-bold text-white">{factor.factor}</h3>
                      <div className="flex items-center mt-1">
                        <div className="h-2 w-32 bg-gray-700 rounded-full overflow-hidden">
                          <div 
                            className={`h-2 bg-gradient-to-r ${getRiskColor(factor.risk_impact)} rounded-full`}
                            style={{ width: factor.risk_impact }}
                          ></div>
                        </div>
                        <span className="ml-2 text-sm text-gray-300">{factor.risk_impact}</span>
                      </div>
                    </div>
                  </div>
                  {expandedFactor === index ? (
                    <ChevronUp className="text-gray-300" size={20} />
                  ) : (
                    <ChevronDown className="text-gray-300" size={20} />
                  )}
                </div>
                
                {expandedFactor === index && (
                  <div className="px-4 pb-4 pt-2 border-t border-white/10">
                    <p className="text-gray-300 mb-4">{factor.description}</p>
                    
                    <h4 className="text-blue-300 font-semibold mb-2">Relevant Data</h4>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-2 mb-4">
                      {Object.entries(factor.relevant_data).map(([key, value]) => (
                        <div key={key} className="flex justify-between">
                          <span className="text-gray-400">{key.replace(/_/g, ' ')}:</span>
                          <span className="font-mono text-white">{value}</span>
                        </div>
                      ))}
                    </div>
                    
                    <h4 className="text-blue-300 font-semibold mb-2">Additional Context</h4>
                    <p className="text-gray-300">{factor.additional_context}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
          
          {/* Right column - Transaction Details */}
          <div>
            <h2 className="text-2xl font-bold text-white mb-4">Transaction Details</h2>
            <div className="backdrop-blur-md bg-white/10 rounded-lg border border-white/20 p-4 shadow-xl">
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-2">
                  <Zap className="text-amber-400" size={20} />
                  <h3 className="font-bold text-white">Transaction Data</h3>
                </div>
                <div className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-sm">
                  ID: TRX-{Math.floor(Math.random() * 1000000)}
                </div>
              </div>
              
              <div className="space-y-3">
                {/* Key transaction details with better visualization */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="backdrop-blur-md bg-gradient-to-br from-blue-900/40 to-blue-800/20 rounded-lg p-3 border border-blue-500/10">
                    <div className="text-sm text-gray-400">Transfer Amount</div>
                    <div className="text-xl font-bold text-white flex items-center">
                      ${data.transaction_analysis.transaction_details.transaction_data.transfer_amount}
                    </div>
                  </div>
                  <div className="backdrop-blur-md bg-gradient-to-br from-red-900/40 to-red-800/20 rounded-lg p-3 border border-red-500/10">
                    <div className="text-sm text-gray-400">Origin Balance Change</div>
                    <div className="text-xl font-bold text-red-300">
                      -{data.transaction_analysis.transaction_details.transaction_data.origin_balance_change_percentage}
                    </div>
                  </div>
                  <div className="backdrop-blur-md bg-gradient-to-br from-emerald-900/40 to-emerald-800/20 rounded-lg p-3 border border-emerald-500/10">
                    <div className="text-sm text-gray-400">Destination Balance Change</div>
                    <div className="text-xl font-bold text-emerald-300">
                      +{data.transaction_analysis.transaction_details.transaction_data.destination_balance_change_percentage}
                    </div>
                  </div>
                  <div className="backdrop-blur-md bg-gradient-to-br from-amber-900/40 to-amber-800/20 rounded-lg p-3 border border-amber-500/10">
                    <div className="text-sm text-gray-400">Fraud Probability</div>
                    <div className="text-xl font-bold text-amber-300">
                      {parseFloat(data.transaction_analysis.transaction_details.transaction_data.fraud_probability_score) * 100}%
                    </div>
                  </div>
                </div>
                
                {/* Detailed transaction data */}
                <div className="space-y-2 backdrop-blur-md bg-white/5 rounded-lg p-4">
                  <h4 className="text-purple-300 font-semibold mb-2">Additional Data Points</h4>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                    {Object.entries(data.transaction_analysis.transaction_details.transaction_data)
                      .filter(([key]) => !['transfer_amount', 'origin_balance_change_percentage', 'destination_balance_change_percentage', 'fraud_probability_score'].includes(key))
                      .map(([key, value]) => (
                        <div key={key} className="flex justify-between border-b border-white/10 py-1">
                          <span className="text-gray-400">{key.replace(/_/g, ' ')}:</span>
                          <span className="font-mono text-white">{value}</span>
                        </div>
                      ))
                    }
                  </div>
                </div>
              </div>
            </div>
            
            {/* Transaction Timeline */}
            <div className="mt-6 backdrop-blur-md bg-white/10 rounded-lg border border-white/20 p-4 shadow-xl">
              <div className="flex items-center gap-2 mb-4">
                <Clock className="text-purple-400" size={20} />
                <h3 className="font-bold text-white">Transaction Timeline</h3>
              </div>
              
              <div className="relative pl-8">
                <div className="absolute left-3 top-0 bottom-0 w-0.5 bg-gray-600"></div>
                
                <div className="relative mb-6">
                  <div className="absolute left-[-18px] w-4 h-4 rounded-full bg-blue-500 shadow-lg shadow-blue-500/50"></div>
                  <div className="backdrop-blur-md bg-white/5 rounded p-3 border border-blue-500/20">
                    <div className="text-sm text-gray-400">Transaction Initiated</div>
                    <div className="text-white">
                      {new Date().toLocaleDateString()} at {data.transaction_analysis.transaction_details.transaction_data.transaction_hour}:
                      {data.transaction_analysis.transaction_details.transaction_data.minute}:
                      {data.transaction_analysis.transaction_details.transaction_data.second}
                    </div>
                  </div>
                </div>
                
                <div className="relative mb-6">
                  <div className="absolute left-[-18px] w-4 h-4 rounded-full bg-amber-500 shadow-lg shadow-amber-500/50"></div>
                  <div className="backdrop-blur-md bg-white/5 rounded p-3 border border-amber-500/20">
                    <div className="text-sm text-gray-400">Risk Analysis Performed</div>
                    <div className="text-white">Risk Score: {data.transaction_analysis.risk_evaluation.overall_risk_score}</div>
                  </div>
                </div>
                
                <div className="relative">
                  <div className="absolute left-[-18px] w-4 h-4 rounded-full bg-red-500 shadow-lg shadow-red-500/50"></div>
                  <div className="backdrop-blur-md bg-white/5 rounded p-3 border border-red-500/20">
                    <div className="text-sm text-gray-400">Further Review Required</div>
                    <div className="text-white">Significant balance changes detected</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
                ) : <p className="text-gray-300">No data found for this user ID.</p>


              }
    
    </div>
  );
};

export default User12;