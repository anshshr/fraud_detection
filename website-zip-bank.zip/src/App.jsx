import "./App.css";
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import Layout from "./components/Layout";
import Error from "./pages/Error";
import Home from "./pages/Home";
import BankDepartment from "./pages/BankDepartment";
import User12 from "./pages/User12";
import UserDashboard from "./pages/UserDashboard";
import UserPaymentDashboard from "./pages/UserPaymentDashboard";
import Check from "./pages/Check";
import { TransactionProvider } from "./TransactionContext";
import AiPage1 from "./pages/AiPage1";
import Register from "./pages/Register";
import Temp from "./pages/Temp";
function App() {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <Layout />,
      errorElement: <Error />,
      children: [
        { index: true, element: <Home /> },
       
        { path: "bankdepartment", element: <BankDepartment /> },
        { path: "bankdepartment/*", element: <BankDepartment /> },
        { path: "userbank/:userId", element: <User12 /> },
        { path: "check", element: <Check/> },
        { path: "userdashboard/:id", element: <UserDashboard /> },
        { path: "userdashboard/userpaymentdashboard", element: <UserPaymentDashboard /> },
        { path: "aipage1", element:  <AiPage1 /> },
        {path: "register", element: <Register/>},
        {path: "temp", element: <Temp/>},

        // {
        //   path: 'admindashboard',
        //   element: (
        //     <PrivateRoute>
        //      <AdiminDashboard/>
        //     </PrivateRoute>
        //   ),
        // },
 
       
      ],
    },
  ]);

  return (
    <>
     
      <RouterProvider router={router} />
    </>
  );
}

export default App;
