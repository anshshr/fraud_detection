import React, { useState } from 'react';
import { MapContainer, TileLayer, Circle, Popup, ZoomControl } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { Shield, AlertTriangle, AlertCircle, CheckCircle, ArrowRight, BarChart3, MapPin, Calendar, Clock, ArrowDown } from 'lucide-react';

// Extended data with more cities and detailed information
const cities = [
  {
    name: 'Maharashtra',
    coordinates: [19.7515, 75.7139],
    riskLevel: 'high',
    color: '#ff0000',
    radius: 6000,
    fraudStats: {
      transactionCount: 34215,
      fraudRate: 8.1,
      alertsToday: 45,
      commonType: 'Card Not Present Fraud'
    }
  },
  {
    name: 'Delhi',
    coordinates: [28.7041, 77.1025],
    riskLevel: 'high',
    color: '#ff0000',
    radius: 5500,
    fraudStats: {
      transactionCount: 19842,
      fraudRate: 7.9,
      alertsToday: 38,
      commonType: 'Identity Theft'
    }
  },
  {
    name: 'Gujarat',
    coordinates: [22.2587, 71.1924],
    riskLevel: 'medium',
    color: '#ffd700',
    radius: 5000,
    fraudStats: {
      transactionCount: 15235,
      fraudRate: 4.5,
      alertsToday: 18,
      commonType: 'Account Takeover'
    }
  },
  {
    name: 'Tamil Nadu',
    coordinates: [11.1271, 78.6569],
    riskLevel: 'medium',
    color: '#ffd700',
    radius: 5200,
    fraudStats: {
      transactionCount: 17485,
      fraudRate: 4.9,
      alertsToday: 21,
      commonType: 'Phishing'
    }
  },
  {
    name: 'West Bengal',
    coordinates: [22.9868, 87.8550],
    riskLevel: 'high',
    color: '#ff0000',
    radius: 5600,
    fraudStats: {
      transactionCount: 18952,
      fraudRate: 6.7,
      alertsToday: 30,
      commonType: 'Counterfeit Cards'
    }
  },
  {
    name: 'Rajasthan',
    coordinates: [27.0238, 74.2179],
    riskLevel: 'low',
    color: '#008000',
    radius: 4000,
    fraudStats: {
      transactionCount: 11458,
      fraudRate: 2.8,
      alertsToday: 10,
      commonType: 'Card Testing'
    }
  },
  {
    name: 'Telangana',
    coordinates: [18.1124, 79.0193],
    riskLevel: 'medium',
    color: '#ffd700',
    radius: 5100,
    fraudStats: {
      transactionCount: 16890,
      fraudRate: 5.2,
      alertsToday: 20,
      commonType: 'Account Takeover'
    }
  },
  {
    name: 'Karnataka',
    coordinates: [15.3173, 75.7139],
    riskLevel: 'medium',
    color: '#ffd700',
    radius: 5300,
    fraudStats: {
      transactionCount: 19236,
      fraudRate: 5.5,
      alertsToday: 22,
      commonType: 'Card Skimming'
    }
  },
  {
    name: 'Uttar Pradesh',
    coordinates: [26.8467, 80.9462],
    riskLevel: 'high',
    color: '#ff0000',
    radius: 5800,
    fraudStats: {
      transactionCount: 21045,
      fraudRate: 7.1,
      alertsToday: 35,
      commonType: 'Synthetic Identity Fraud'
    }
  },
  {
    name: 'Madhya Pradesh',
    coordinates: [23.2599, 77.4126],
    riskLevel: 'low',
    color: '#008000',
    radius: 4200,
    fraudStats: {
      transactionCount: 10258,
      fraudRate: 2.5,
      alertsToday: 9,
      commonType: 'Friendly Fraud'
    }
  }
];

const getRiskLabel = (riskLevel) => {
  switch (riskLevel) {
    case 'high':
      return 'High Risk Area';
    case 'medium':
      return 'Medium Risk Area';
    case 'low':
      return 'Safe Area';
    default:
      return '';
  }
};

const getRiskIcon = (riskLevel) => {
  switch (riskLevel) {
    case 'high':
      return <AlertTriangle className="h-5 w-5 text-red-500" />;
    case 'medium':
      return <AlertCircle className="h-5 w-5 text-yellow-500" />;
    case 'low':
      return <CheckCircle className="h-5 w-5 text-green-500" />;
    default:
      return null;
  }
};

function Map12() {
  const [selectedCity, setSelectedCity] = useState(null);
  const [isStatsVisible, setIsStatsVisible] = useState(true);

  const handleCityClick = (city) => {
    setSelectedCity(city);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-2 rounded-lg mr-3">
              <Shield className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-100">
              FraudShield <span className="text-green-400">Risk Map</span>
            </h1>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="bg-gray-800/80 backdrop-blur-md px-4 py-2 rounded-lg border border-gray-700/50 shadow-md flex items-center">
              <Clock className="h-4 w-4 text-green-400 mr-2" />
              <span className="text-sm text-gray-300">Last updated: Today, 14:35 IST</span>
            </div>
            <button className="bg-gradient-to-r from-green-500 to-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center hover:opacity-90 transition-all shadow-md shadow-green-500/20">
              View Reports <ArrowRight size={16} className="ml-2" />
            </button>
          </div>
        </div>

        {/* Main content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left column - Stats */}
          <div className="lg:col-span-1">
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-xl overflow-hidden shadow-xl mb-6">
              <div className="p-4 bg-gradient-to-r from-gray-800/80 to-gray-800/60 border-b border-gray-700/50 flex justify-between items-center">
                <div className="flex items-center">
                  <BarChart3 className="h-5 w-5 text-green-400 mr-2" />
                  <h2 className="text-lg font-semibold text-white">Fraud Statistics</h2>
                </div>
                <button 
                  className="text-gray-400 hover:text-white"
                  onClick={() => setIsStatsVisible(!isStatsVisible)}
                >
                  <ArrowDown className={`h-4 w-4 transition-transform ${isStatsVisible ? 'rotate-180' : ''}`} />
                </button>
              </div>
              
              {isStatsVisible && (
                <div className="p-5">
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-gray-700/30 backdrop-blur-sm p-4 rounded-lg border border-gray-600/30">
                      <p className="text-gray-400 text-sm mb-1">Total Transactions Today</p>
                      <p className="text-2xl font-bold text-white">87,429</p>
                    </div>
                    <div className="bg-gray-700/30 backdrop-blur-sm p-4 rounded-lg border border-gray-600/30">
                      <p className="text-gray-400 text-sm mb-1">Fraud Alerts Today</p>
                      <p className="text-2xl font-bold text-red-400">237</p>
                    </div>
                    <div className="bg-gray-700/30 backdrop-blur-sm p-4 rounded-lg border border-gray-600/30">
                      <p className="text-gray-400 text-sm mb-1">Average Fraud Rate</p>
                      <p className="text-2xl font-bold text-yellow-400">5.2%</p>
                    </div>
                    <div className="bg-gray-700/30 backdrop-blur-sm p-4 rounded-lg border border-gray-600/30">
                      <p className="text-gray-400 text-sm mb-1">High Risk Areas</p>
                      <p className="text-2xl font-bold text-green-400">3</p>
                    </div>
                  </div>
                  
                  {selectedCity ? (
                    <div className="bg-gradient-to-br from-gray-700/40 to-gray-800/40 backdrop-blur-md p-5 rounded-lg border border-gray-600/30">
                      <div className="flex items-center mb-4">
                        <MapPin className="h-5 w-5 text-green-400 mr-2" />
                        <h3 className="text-xl font-semibold text-white">{selectedCity.name}</h3>
                        {getRiskIcon(selectedCity.riskLevel)}
                      </div>
                      
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Risk Level:</span>
                          <span className={`font-medium ${
                            selectedCity.riskLevel === 'high' ? 'text-red-400' : 
                            selectedCity.riskLevel === 'medium' ? 'text-yellow-400' : 'text-green-400'
                          }`}>
                            {getRiskLabel(selectedCity.riskLevel)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Transactions:</span>
                          <span className="font-medium text-white">{selectedCity.fraudStats.transactionCount.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Fraud Rate:</span>
                          <span className="font-medium text-white">{selectedCity.fraudStats.fraudRate}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Alerts Today:</span>
                          <span className="font-medium text-white">{selectedCity.fraudStats.alertsToday}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Common Type:</span>
                          <span className="font-medium text-white">{selectedCity.fraudStats.commonType}</span>
                        </div>
                      </div>
                      
                      <button className="w-full mt-4 bg-gradient-to-r from-green-500 to-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center justify-center hover:opacity-90 transition-all">
                        View Detailed Report
                      </button>
                    </div>
                  ) : (
                    <div className="bg-gradient-to-br from-gray-700/40 to-gray-800/40 backdrop-blur-md p-5 rounded-lg border border-gray-600/30 text-center">
                      <MapPin className="h-6 w-6 text-green-400 mx-auto mb-3" />
                      <p className="text-gray-300 mb-2">Select a city on the map</p>
                      <p className="text-gray-400 text-sm">Click on any city marker to view detailed fraud statistics</p>
                    </div>
                  )}
                </div>
              )}
            </div>
            
            {/* Legend */}
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-xl overflow-hidden shadow-xl">
              <div className="p-4 bg-gradient-to-r from-gray-800/80 to-gray-800/60 border-b border-gray-700/50">
                <h2 className="text-lg font-semibold text-white">Risk Level Legend</h2>
              </div>
              <div className="p-5">
                <div className="space-y-4">
                  <div className="flex items-center">
                    <div className="w-4 h-4 rounded-full bg-red-500 mr-3"></div>
                    <span className="text-gray-300">High Risk Area (6% fraud rate)</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-4 h-4 rounded-full bg-yellow-400 mr-3"></div>
                    <span className="text-gray-300">Medium Risk Area (3-6% fraud rate)</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-4 h-4 rounded-full bg-green-500 mr-3"></div>
                    <span className="text-gray-300">Safe Area (3% fraud rate)</span>
                  </div>
                </div>
                
                <div className="mt-5 pt-5 border-t border-gray-700/50">
                  <h3 className="text-sm font-semibold text-green-400 mb-3">Top Fraud Types</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Card Not Present Fraud</span>
                      <span className="text-white">32%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Identity Theft</span>
                      <span className="text-white">28%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Account Takeover</span>
                      <span className="text-white">19%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Phishing</span>
                      <span className="text-white">14%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Others</span>
                      <span className="text-white">7%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Right column - Map */}
          <div className="lg:col-span-2">
            <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-xl overflow-hidden shadow-xl h-[700px]">
              <div className="p-4 bg-gradient-to-r from-gray-800/80 to-gray-800/60 border-b border-gray-700/50">
                <h2 className="text-lg font-semibold text-white">Online Transaction Risk Map</h2>
              </div>
              
              <div className="h-[650px] w-full">
                <MapContainer
                  center={[20.5937, 78.9629]}
                  zoom={5}
                  style={{ height: '100%', width: '100%' }}
                  zoomControl={false}
                >
                  <ZoomControl position="bottomright" />
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  />
                  
                  {cities.map((city) => (
                    <Circle
                      key={city.name}
                      center={city.coordinates}
                      radius={city.radius}
                      pathOptions={{
                        fillColor: city.color,
                        fillOpacity: 0.5,
                        color: city.color,
                        weight: 2
                      }}
                      eventHandlers={{
                        click: () => handleCityClick(city)
                      }}
                    >
                      <Popup>
                        <div className="text-center">
                          <h3 className="font-bold text-gray-800">{city.name}</h3>
                          <p className={`font-medium ${
                            city.riskLevel === 'high' ? 'text-red-600' : 
                            city.riskLevel === 'medium' ? 'text-yellow-600' : 'text-green-600'
                          }`}>
                            {getRiskLabel(city.riskLevel)}
                          </p>
                          <p className="text-gray-600 text-sm mt-1">Fraud Rate: {city.fraudStats.fraudRate}%</p>
                          <button 
                            className="mt-2 px-3 py-1 bg-blue-500 text-white text-xs rounded-full hover:bg-blue-600 transition-colors"
                            onClick={() => handleCityClick(city)}
                          >
                            View Details
                          </button>
                        </div>
                      </Popup>
                    </Circle>
                  ))}
                </MapContainer>
              </div>
            </div>
          </div>
        </div>
        
        {/* Time period selector */}
        <div className="mt-6 backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-xl overflow-hidden shadow-xl">
          <div className="p-4">
            <div className="flex flex-wrap items-center justify-between">
              <div className="flex items-center mb-4 sm:mb-0">
                <Calendar className="h-5 w-5 text-green-400 mr-2" />
                <h3 className="text-lg font-semibold text-white">Time Period</h3>
              </div>
              
              <div className="flex flex-wrap gap-2">
                <button className="px-4 py-1.5 rounded-lg text-sm font-medium bg-gradient-to-r from-green-500 to-emerald-700 text-white">Today</button>
                <button className="px-4 py-1.5 rounded-lg text-sm font-medium bg-gray-700/50 text-gray-300 hover:bg-gray-700/80 transition-colors">7 Days</button>
                <button className="px-4 py-1.5 rounded-lg text-sm font-medium bg-gray-700/50 text-gray-300 hover:bg-gray-700/80 transition-colors">30 Days</button>
                <button className="px-4 py-1.5 rounded-lg text-sm font-medium bg-gray-700/50 text-gray-300 hover:bg-gray-700/80 transition-colors">Quarter</button>
                <button className="px-4 py-1.5 rounded-lg text-sm font-medium bg-gray-700/50 text-gray-300 hover:bg-gray-700/80 transition-colors">Year</button>
                <button className="px-4 py-1.5 rounded-lg text-sm font-medium bg-gray-700/50 text-gray-300 hover:bg-gray-700/80 transition-colors">Custom</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Map12;