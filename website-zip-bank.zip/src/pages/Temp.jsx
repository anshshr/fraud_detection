// src/pages/AiPage1.js
import React, { useState, useContext } from "react";
import { TransactionContext } from "../TransactionContext";
import { GoogleGenerativeAI } from "@google/generative-ai";

// Initialize Gemini API (replace with your actual API key)
  const genAI = new GoogleGenerativeAI("AIzaSyC9Uzc1ZyQ3ve_AHqYtN6H8sk-n0wgpqmM");
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

const Temp = () => {
 
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [aiResponse, setAiResponse] = useState(null);

  const handleAIAnalysis = async () => {
  

    setLoading(true);
    setError(null);
    setAiResponse(null); // Clear previous response

    const currentDate = new Date();
    

    const transactionData = {
      step: "1",
      type: "4",
      amount: 5000,
      oldbalanceOrg: 20000,
      newbalanceOrig: 15000,
      oldbalanceDest: 10000,
      newbalanceDest: 15000,
      balance_change_org: -5000,
      balance_change_dest: 5000,
      city_size: "2",
      card_type: "0",
      device_id: "1423",
      channel_used: "2",
      distance_from_home: "15",
      transaction_hour: currentDate.getHours().toString(),
      weekend_transaction: currentDate.getDay() === 0 || currentDate.getDay() === 6 ? "1" : "0",
      year: currentDate.getFullYear().toString(),
      month: (currentDate.getMonth() + 1).toString(),
      day: currentDate.getDate().toString(),
      hour: currentDate.getHours().toString(),
      minute: currentDate.getMinutes().toString(),
      second: currentDate.getSeconds().toString(),
      microsecond: "0",
      USD_converted_amount: "5000",
      is_bank_operating: "1",
      merchant_category_label: "35.0",
      ip_address: "192.168.1.100",
      location_coordinates: "23.0339, 72.5850", // Example coordinates for Ahmedabad
      transaction_currency: "USD",
      time_since_last_transaction: "2 hours",
      sender_account_verified: "Yes",
      receiver_account_verified: "No",
      payment_method: "Credit Card",
      transaction_purpose: "Online Purchase",
      device_os: "Android",
      browser: "Chrome",
    };

    // Construct refined AI prompt for fraud analysis
    const requestData = {
      transaction_analysis: {
        report_summary:
          "Analyze the given financial transaction and provide a structured risk evaluation. Assess potential fraud indicators based on transaction details, user behavior, and contextual data.",

        risk_evaluation: {
          overall_risk_score: "Pending AI Analysis",
          risk_factors: [
            {
              factor: "Significant Balance Alteration",
              description:
                "Assess the percentage change in sender and receiver account balances. Identify if the sender's balance falls below a critical threshold.",
              risk_impact: "Pending AI Analysis",
              relevant_data: {
                transfer_amount: 5000,
                origin_account_initial: 20000,
                origin_account_final: 15000,
                destination_account_initial: 10000,
                destination_account_final: 15000,
                origin_balance_change_percent: ((5000 / 20000) * 100).toFixed(2) + "%",
                destination_balance_change_percent: ((5000 / 10000) * 100).toFixed(2) + "%",
              },
            },
            {
              factor: "Transaction Classification and Stage",
              description:
                "Evaluate transaction type and step codes. Analyze if the transaction type aligns with typical user behavior.",
              risk_impact: "Pending AI Analysis",
              relevant_data: {
                transaction_type_code: transactionData.type,
                transaction_stage: transactionData.step,
              },
            },
            {
              factor: "Pre-calculated Fraud Probability",
              description:
                "Assess AI-predicted fraud probability based on historical patterns and transaction behavior.",
              risk_impact: "Pending AI Analysis",
              relevant_data: {
                fraud_probability_score: "Pending AI Analysis",
              },
            },
            {
              factor: "Geolocation & Device Analysis",
              description:
                "Verify transaction proximity to the sender’s registered location and check if the device used is recognized.",
              risk_impact: "Pending AI Analysis",
              relevant_data: {
                device_id: transactionData.device_id,
                distance_from_home: transactionData.distance_from_home,
              },
            },
            // Add more risk factors based on dummy data
            {
              factor: "IP Address Analysis",
              description: "Analyze the IP address associated with the transaction for any suspicious activity or known high-risk origins.",
              risk_impact: "Pending AI Analysis",
              relevant_data: {
                ip_address: transactionData.ip_address,
              },
            },
            {
              factor: "Location Coordinates",
              description: "Verify if the transaction location aligns with the user's typical location.",
              risk_impact: "Pending AI Analysis",
              relevant_data: {
                location_coordinates: transactionData.location_coordinates,
              },
            },
            {
              factor: "Account Verification Status",
              description: "Assess the verification status of the sender and receiver accounts.",
              risk_impact: "Pending AI Analysis",
              relevant_data: {
                sender_account_verified: transactionData.sender_account_verified,
                receiver_account_verified: transactionData.receiver_account_verified,
              },
            },
            {
              factor: "Payment Method",
              description: "Analyze the payment method used for any associated risks.",
              risk_impact: "Pending AI Analysis",
              relevant_data: {
                payment_method: transactionData.payment_method,
              },
            },
          ],
        },

        transaction_details: { transaction_data: transactionData },
      },
    };

    const prompt = `Analyze the following financial transaction for potential fraud, considering the transaction details. Provide a structured risk evaluation based on the provided information.

${JSON.stringify(requestData, null, 2)}

Focus on identifying potential risk factors and provide an overall fraud probability (High, Medium, Low) based on your analysis.`;

    try {
      setLoading(true);
      setError(null);

      const result = await model.generateContent(prompt);
      const responseText = result?.response?.candidates?.[0]?.content?.parts?.[0]?.text;
      console.log("Gemini Response:", responseText);
      setAiResponse(responseText);

    } catch (err) {
      console.error("Gemini Analysis Error:", err);
      setError(`Error fetching AI analysis: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 pt-20 max-w-lg mx-auto text-center">
      <h2 className="text-2xl font-bold">AI Transaction Analysis</h2>

      <button
        onClick={handleAIAnalysis}
        className="mt-5 px-6 py-3 bg-purple-600 text-white rounded-lg shadow-md hover:bg-purple-700 disabled:bg-gray-400"
        disabled={loading}
      >
        {loading ? "Analyzing..." : "Analyze Transaction"}
      </button>

      {error && <p className="text-red-500 mt-3">{error}</p>}

      {aiResponse && (
        <div className="mt-5 text-left border p-4 rounded-md bg-gray-100">
          <h3 className="text-lg font-semibold mb-2">AI Analysis Result:</h3>
          <pre className="whitespace-pre-wrap">{aiResponse}</pre>
        </div>
      )}
    </div>
  );
};

export default Temp;