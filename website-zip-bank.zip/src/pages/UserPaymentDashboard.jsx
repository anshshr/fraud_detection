import React, { useState, useEffect ,useContext} from 'react';
import { X, Send, User, Phone, MapPin, DollarSign } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import axios from "axios";
import { TransactionContext } from "../TransactionContext";

const UserPaymentDashboard = () => {
  // State for users and selected user
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [mainuser, setMainUser] = useState(null);
  const { aiuser1, setaiuser1, aiuser2, setaiuser2 ,amount, setAmount } = useContext(TransactionContext);
 const navigate = useNavigate();
  const handleSubmit = async (e) => {
    e.preventDefault();
    navigate('/aipage1');
    // try {
    //     const response = await axios.post("http://localhost:5000/api/users/transactions", {
    //       sender: mainuser._id, // Sender's User ID
    //     receiver: selectedUser._id, // Receiver's User ID
    //     amount: paymentAmount,
    //     senderImageUrl: mainuser.personalDetails.imageUrl,
    //     receiverImageUrl: selectedUser.personalDetails.imageUrl,
    //     senderLocation: mainuser.personalDetails.address.city,
    //     receiverLocation: selectedUser.personalDetails.address.city,
    //     });
    //     alert("✅ Transaction Successful!");
    //     console.log(response.data);
    // } catch (error) {
    //     alert("❌ Transaction Failed: " + (error.response?.data?.message || "Server error"));
    //     console.error("Transaction Error:", error);
    // }
};
  // Fetch users (mock data for now)
  useEffect(() => {
    // Simulate fetching users
    const fetchUsers = async () => {
      try {
        // This would be replaced with actual API call
        // For example: const response = await fetch('/api/users');
        // const data = await response.json();
        const response = await axios.get(`http://localhost:5000/api/users/getusers`);
         setUsers(response.data);
        
        // Mock data based on the schema
         console.log(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching users:', error);
        setLoading(false);
      }
    };



    const fetchUserData = async () => {
      try {
        setLoading(true);
        // Replace with your actual API endpoint
        const response = await axios.get('http://localhost:5000/api/users/users/67e886bafbf909a686e608af');
        setaiuser1(response.data);
        setMainUser(response.data);
        console.log(response.data);
        setLoading(false);
      } catch (err) {
        
        setLoading(false);
        console.error(err);
      }
    };
    fetchUserData();
    fetchUsers();
  }, []);

  // Handle payment submission
  const handlePaymentSubmit = (e) => {
    e.preventDefault();
    
    if (!selectedUser) {
      alert('Please select a recipient');
      return;
    }

    // Here you would actually process the payment
    alert(`Payment of $${paymentAmount} sent to ${selectedUser.name}`);
    
    // Reset form
    setPaymentAmount('');
    setShowPaymentModal(false);
  };

  // Format date to readable string
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric', 
      month: 'short', 
      day: 'numeric'
    });
  };

  return (
    <div className="flex flex-col pt-[5rem] md:flex-row w-full h-screen bg-gray-900 text-white">
      {/* Left side - User list */}
      <div className="w-full md:w-1/3 p-4 overflow-y-auto border-r border-gray-700">
        <h2 className="text-xl font-bold text-green-400 mb-4">Users</h2>
        
        {loading ? (
          <div className="flex justify-center items-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-green-400"></div>
          </div>
        ) : (
          <div className="space-y-3">
            {users.map(user => (
              <div 
                key={user._id}
                className={`p-3 rounded-lg cursor-pointer transition-all ${
                  selectedUser && selectedUser._id === user._id
                    ? 'bg-gray-700 border-l-4 border-green-400'
                    : 'bg-gray-800 hover:bg-gray-700'
                }`}
                onClick={() => {
                setaiuser2(user);
                  setSelectedUser(user);
                }}
              >
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="bg-gray-700 rounded-full p-2 mr-3">
                      <User className="h-5 w-5 text-green-400" />
                    </div>
                    <div>
                      <h3 className="font-medium">{user.name}</h3>
                      <p className="text-sm text-gray-400">{user.email}</p>
                    </div>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded ${
                    user.role === 'admin' ? 'bg-purple-900 text-purple-200' : 'bg-blue-900 text-blue-200'
                  }`}>
                    {user.role}
                  </span>
                </div>
                
                <div className="mt-2 grid grid-cols-2 gap-2 text-sm text-gray-400">
                  <div className="flex items-center">
                    <Phone className="h-3 w-3 mr-1" />
                    <span>{user.personalDetails.phoneNumber}</span>
                  </div>
                  <div className="flex items-center">
                    <MapPin className="h-3 w-3 mr-1" />
                    <span>{user.personalDetails.address.city}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Right side - Payment section */}
      <div className="w-full md:w-2/3 p-4">
        {selectedUser ? (
          <div className="h-full">
            <div className="bg-gray-800 rounded-xl p-6 shadow-lg">
              <h2 className="text-xl font-bold text-green-400 mb-4">User Details</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-medium">{selectedUser.name}</h3>
                    <p className="text-gray-400">{selectedUser.email}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-sm text-gray-400 uppercase">Personal Details</h4>
                    <div className="mt-2 space-y-2">
                      <div>
                        <span className="text-gray-500">Date of Birth:</span> {formatDate(selectedUser.personalDetails.dateOfBirth)}
                      </div>
                      <div>
                        <span className="text-gray-500">Phone:</span> {selectedUser.personalDetails.phoneNumber}
                      </div>
                    </div>
                  </div>
                  
                 
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm text-gray-400 uppercase">Bank Details</h4>
                    <div className="mt-2 space-y-2">
                      <div>
                        <span className="text-gray-500">Account:</span> •••••{selectedUser.bankDetails.accountNumber.slice(-4)}
                      </div>
                      <div>
                        <span className="text-gray-500">IFSC:</span> {selectedUser.bankDetails.ifscCode}
                      </div>
                    
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <button
                      onClick={() => setShowPaymentModal(true)}
                      className="w-full py-3 bg-green-500 hover:bg-green-600 rounded-lg flex items-center justify-center transition-colors"
                    >
                      <DollarSign className="mr-2 h-5 w-5" /> Make Payment to {selectedUser.name}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="h-full flex items-center justify-center">
            <div className="text-center text-gray-500">
              <User className="h-16 w-16 mx-auto mb-4 opacity-30" />
              <p>Select a user from the list to view details and make a payment</p>
            </div>
          </div>
        )}
      </div>
      
      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-gray-800 bg-opacity-90 backdrop-blur-lg rounded-xl border border-gray-700 p-6 w-full max-w-md shadow-xl">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-green-400">Make a Payment</h3>
              <button onClick={() => setShowPaymentModal(false)}>
                <X className="h-5 w-5 text-gray-400 hover:text-white" />
              </button>
            </div>
            <form onSubmit={handlePaymentSubmit}>
              <div className="mb-4">
                <label className="block text-gray-400 mb-2">Recipient</label>
                <div className="w-full bg-gray-700 bg-opacity-50 border border-gray-600 rounded-lg px-4 py-2">
                  {selectedUser?.name} (Acc: •••••{selectedUser?.bankDetails.accountNumber.slice(-4)})
                </div>
              </div>
              <div className="mb-6">
                <label className="block text-gray-400 mb-2">Amount ($)</label>
                <input
                  type="number"
                  value={paymentAmount}
                  onChange={(e) =>{ setPaymentAmount(e.target.value);
                  setAmount(e.target.value);
                  }}
                  className="w-full bg-gray-700 bg-opacity-50 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                  placeholder="0.00"
                  min="0.01"
                  step="0.01"
                  required
                />
              </div>
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  className="mr-2 px-4 py-2 border border-gray-600 rounded-lg hover:bg-gray-700 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-green-500 hover:bg-green-600 rounded-lg flex items-center transition-colors" onClick={handleSubmit}
                >
                  <Send className="mr-2 h-4 w-4" /> Send Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserPaymentDashboard;