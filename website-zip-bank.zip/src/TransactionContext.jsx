import React, { createContext, useState } from "react";

// Create a new context
export const TransactionContext = createContext();

// Create a Provider component
export const TransactionProvider = ({ children }) => {
 

 
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [amount, setAmount] = useState(null);
  const [aiuser1, setaiuser1] = useState(null);

  const [aiuser2, setaiuser2] = useState(null);

  const [otpsuc,setotpsuc]=useState(false);
  // Function to fetch prediction

  return (
    <TransactionContext.Provider value={{  loading, error, aiuser1, setaiuser1, aiuser2, setaiuser2 , amount, setAmount, otpsuc, setotpsuc}}>
      {children}
    </TransactionContext.Provider>
  );
};
