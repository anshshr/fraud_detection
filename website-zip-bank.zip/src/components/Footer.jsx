import React from 'react';
import { Shield, Mail, Phone, MapPin, Github, Linkedin, Twitter, Instagram, ChevronRight } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-b mt-[6rem] from-gray-900 to-black text-white relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-green-500/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-2 rounded-lg">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <span className="text-white font-bold text-xl">FraudShield</span>
            </div>
            <p className="text-gray-400 mb-6">
              A global innovation partner for next-gen digital solutions. We guide visionaries to create purposeful impact by building memorable products.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-green-400 transition-colors">
                <Github size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-green-400 transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-green-400 transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-green-400 transition-colors">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6 text-green-400">Quick Links</h3>
            <ul className="space-y-3">
              {['Home', 'Features', 'Technology', 'About Us', 'Contact'].map((item, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-400 hover:text-green-400 flex items-center gap-2 transition-colors">
                    <ChevronRight size={16} className="text-green-500" />
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Features */}
          <div>
            <h3 className="text-lg font-semibold mb-6 text-green-400">Features</h3>
            <ul className="space-y-3">
              {[
                'Real-time Monitoring', 
                'Anomaly Detection', 
                'Actionable Alerts', 
                'Regulatory Compliance',
                'Multi-Agent System'
              ].map((item, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-400 hover:text-green-400 flex items-center gap-2 transition-colors">
                    <ChevronRight size={16} className="text-green-500" />
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-6 text-green-400">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin size={20} className="text-green-500 flex-shrink-0 mt-1" />
                <span className="text-gray-400">123 Innovation Street, Tech Valley, CA 94103</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={20} className="text-green-500 flex-shrink-0" />
                <span className="text-gray-400">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={20} className="text-green-500 flex-shrink-0" />
                <span className="text-gray-400">info@fraudshield.tech</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Newsletter */}
        <div className="backdrop-blur-md bg-gray-800/30 border border-gray-700/50 rounded-xl p-6 mb-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            <div className="md:col-span-2">
              <h3 className="text-xl font-semibold mb-2 text-white">Subscribe to Our Newsletter</h3>
              <p className="text-gray-400">Stay updated with the latest in AI fraud detection technology</p>
            </div>
            <div>
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="Your email" 
                  className="bg-gray-700/50 border border-gray-600 text-white rounded-l-lg px-4 py-2 w-full focus:outline-none focus:ring-2 focus:ring-green-500"
                />
                <button className="bg-gradient-to-r from-green-500 to-emerald-700 text-white px-4 py-2 rounded-r-lg font-medium hover:opacity-90 transition-all">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 py-6 border-t border-b border-gray-800 mb-8">
          <div className="text-center">
            <p className="text-3xl font-bold text-green-400">11+</p>
            <p className="text-gray-400">Years</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-green-400">150+</p>
            <p className="text-gray-400">Clients</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-green-400">400+</p>
            <p className="text-gray-400">Products</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-green-400">140+</p>
            <p className="text-gray-400">Global Team</p>
          </div>
        </div>

        {/* Bottom */}
        <div className="flex flex-col md:flex-row justify-between items-center pt-6">
          <p className="text-gray-500 text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} FraudShield. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-gray-500 hover:text-green-400 text-sm transition-colors">Privacy Policy</a>
            <a href="#" className="text-gray-500 hover:text-green-400 text-sm transition-colors">Terms of Service</a>
            <a href="#" className="text-gray-500 hover:text-green-400 text-sm transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;