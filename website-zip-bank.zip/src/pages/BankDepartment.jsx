import React, { useState,useEffect } from 'react';
import { 
  Home, 
  Map, 
  LogOut, 
  AlertTriangle, 
  Eye, 
  Search,
  ArrowUpRight,
  CreditCard,
  Wallet,
  BarChart4,
  Activity,
  Users
} from 'lucide-react';
import { FraudDetectionMap } from './FraudDetectionMap';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../firebase/firebase';

import MainBankDashboard from './MainBankDashboard';
import Map12 from '../components/Map12';

// Mock data for transactions


// Component for sidebar item
const SidebarItem = ({ icon, text, active, onClick }) => (
  <div 
    onClick={onClick}
    className={`flex items-center space-x-3 p-3 rounded-lg cursor-pointer transition-all duration-200 ${
      active ? 'bg-white/10 text-white' : 'text-white/70 hover:bg-white/5 hover:text-white'
    }`}
  >
    {icon}
    <span className="font-medium">{text}</span>
  </div>
);



// Main component
const BankDepartment = () => {
  const [activeTab, setActiveTab] = useState('dashboard');

 
  // Components for different tabs
  const renderContent = () => {
    switch(activeTab) {
      case 'fraudMap':
        return <Map12/> ;
      default:
        return <MainBankDashboard />;
    }
  };
  
  // Main Dashboard component
 
  
  // Fraud Detection Map component (placeholder)
 
   

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800 text-white">
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 h-screen sticky mt-[3rem] top-0 p-4">
          <div className="h-full backdrop-blur-md bg-slate-900/60 rounded-xl p-4 border border-white/5 shadow-lg flex flex-col">
            <div className="p-4 mb-6 flex items-center space-x-2">
              <div className="h-10 w-10 bg-gradient-to-r from-teal-400 to-emerald-500 rounded-lg flex items-center justify-center">
                <AlertTriangle size={24} className="text-slate-900" />
              </div>
              <div>
                <h1 className="text-white font-bold text-lg">FraudGuard</h1>
                <p className="text-white/50 text-xs">AI Fraud Detection</p>
              </div>
            </div>
            
            <div className="space-y-2 flex-grow">
              <SidebarItem 
                icon={<Home size={20} />} 
                text="Dashboard" 
                active={activeTab === 'dashboard'} 
                onClick={() => setActiveTab('dashboard')}
              />
              <SidebarItem 
                icon={<Map size={20} />} 
                text="Fraud Detection Map" 
                active={activeTab === 'fraudMap'} 
                onClick={() => setActiveTab('fraudMap')}
              />
              <SidebarItem 
                icon={<BarChart4 size={20} />} 
                text="Analytics" 
                active={activeTab === 'analytics'} 
                onClick={() => {}}
              />
              <SidebarItem 
                icon={<AlertTriangle size={20} />} 
                text="Alerts" 
                active={activeTab === 'alerts'} 
                onClick={() => {}}
              />
              <SidebarItem 
                icon={<Users size={20} />} 
                text="Users" 
                active={activeTab === 'users'} 
                onClick={() => {}}
              />
            </div>
            
            <div className="pt-4 border-t border-slate-700/50">
              <SidebarItem 
                icon={<LogOut size={20} />} 
                text="Logout" 
                active={false} 
                onClick={() => {}}
              />
            </div>
          </div>
        </div>
        
        {/* Main content */}
        <div className="flex-1 p-[2rem]">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default BankDepartment;