import React from 'react';

const Loader = () => {
  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
      <div className="bg-gray-800 bg-opacity-60 backdrop-blur-lg border border-gray-700 rounded-xl shadow-lg p-8 max-w-md w-full">
        {/* Logo/Brand placeholder */}
        <div className="flex justify-center mb-8">
          <div className="h-16 w-16 rounded-full bg-gradient-to-r from-green-500 to-green-300 flex items-center justify-center">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="h-8 w-8 text-white"
            >
              <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
            </svg>
          </div>
        </div>
        
        {/* Text */}
        <div className="text-center mb-8">
          <h2 className="text-xl font-bold text-green-400 mb-2">Loading Your Dashboard</h2>
          <p className="text-gray-400">Please wait while we secure your connection...</p>
        </div>
        
        {/* Loading animation */}
        <div className="flex flex-col items-center">
          {/* Spinning circle */}
          <div className="relative h-16 w-16 mb-6">
            <div className="absolute inset-0 rounded-full border-4 border-gray-700"></div>
            <div className="absolute inset-0 rounded-full border-t-4 border-green-400 animate-spin"></div>
          </div>
          
          {/* Progress bar */}
          <div className="w-full bg-gray-700 rounded-full h-2.5 mb-3 overflow-hidden">
            <div className="bg-green-400 h-2.5 rounded-full animate-pulse" style={{width: '75%'}}></div>
          </div>
          
          {/* Loading steps */}
          <div className="text-xs text-gray-400 flex items-center">
            <span className="inline-block h-1.5 w-1.5 bg-green-400 rounded-full mr-2 animate-pulse"></span>
            Verifying credentials...
          </div>
        </div>
        
        {/* Glass reflections - purely decorative */}
        <div className="absolute top-0 left-0 w-full h-1/3 bg-white opacity-5 rounded-t-xl"></div>
      </div>
    </div>
  );
};

export default Loader;