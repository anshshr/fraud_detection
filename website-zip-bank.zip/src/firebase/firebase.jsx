import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  onAuthStateChanged,  
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut 
} from "firebase/auth";
import { useState, useEffect, useContext, createContext } from "react";
import { getFirestore, collection, getDocs } from "firebase/firestore";
// 🔐 Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyCmNCIUpRubTB9FZK3hp9W3D2YbOkNUV9c",
  authDomain: "frauddetection-9a31d.firebaseapp.com",
  projectId: "frauddetection-9a31d",
  storageBucket: "frauddetection-9a31d.firebasestorage.app",
  messagingSenderId: "63428814218",
  appId: "1:63428814218:web:d9dcd78a9fd3fe27129473",
  measurementId: "G-6CG131D7T7"
};

// 🚀 Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
const db = getFirestore(app);
// 🔄 Create Firebase Context
const FirebaseContext = createContext(null);
export const useFirebase = () => useContext(FirebaseContext);

// 🟢 Google Sign-In
export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error) {
    console.error("Google Sign-In Error:", error);
  }
};

// 🔴 Google Sign-Out
export const logout = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error("Logout Error:", error);
  }
};

export const listenForAuthChanges = (setUser) => {
  onAuthStateChanged(auth, (user) => {
    if (user) {
      setUser(user);
    } else {
      setUser(null);
    }
  });
};


// 🛠️ Firebase Provider Component
export const FirebaseProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [userUid, setUserUid] = useState("");

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUser(user);
        setUserUid(user.uid);
      } else {
        setUser(null);
        setUserUid("");
      }
    });

    // Cleanup subscription on unmount
    return () => unsubscribe();
  }, []);

  return (
    <FirebaseContext.Provider value={{ user, userUid, isLoggedIn: !!user, signInWithGoogle, logout ,listenForAuthChanges}}>
      {children}
    </FirebaseContext.Provider>
  );
};

// Export Firebase instances
export { app, auth ,db };
